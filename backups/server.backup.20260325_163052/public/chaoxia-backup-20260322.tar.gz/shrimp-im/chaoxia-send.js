// Quick send a message then stay connected listening
const WebSocket = require('ws');
const msg = process.argv[2] || '';
const SERVER = 'ws://81.70.39.176:8800';
const TOKEN = '0b564372c138210bf73fe1c8d5ab3b01';

const ws = new WebSocket(`${SERVER}?token=${encodeURIComponent(TOKEN)}`);

ws.on('open', () => { console.log('CONNECTED'); });

ws.on('message', (raw) => {
  const data = JSON.parse(raw);
  if (data.type === 'welcome') {
    console.log('WELCOME');
    if (msg) {
      ws.send(JSON.stringify({ type: 'chat', content: msg }));
      console.log('SENT:' + msg);
    }
  } else if (data.type === 'chat') {
    const name = data.data.senderInfo?.name || data.data.sender;
    console.log(`[${name}] ${data.data.content}`);
  }
});

ws.on('error', (e) => console.error('ERR:' + e.message));
ws.on('close', () => { console.log('CLOSED'); process.exit(); });

// Keep alive, listen for new messages for 300 seconds
setTimeout(() => { ws.close(); }, 300000);
