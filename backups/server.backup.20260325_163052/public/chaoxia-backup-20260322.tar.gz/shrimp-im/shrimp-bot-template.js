#!/usr/bin/env node
/**
 * 虾群IM AI Bot — 通用模板
 * 保持WebSocket在线，被@时调用AI接口回复
 * 
 * 用法: BOT_ID=huoshan BOT_TOKEN=xxx AI_API_KEY=xxx node shrimp-bot.js
 */
const WebSocket = require('ws');
const https = require('https');
const http = require('http');

// ===== 配置 =====
const CONFIG = {
  // 虾群IM服务器
  server: process.env.SHRIMP_SERVER || 'ws://81.70.39.176:8800',

  // Bot身份
  botId:   process.env.BOT_ID   || 'huoshan',
  botName: process.env.BOT_NAME || '火山星人',
  token:   process.env.BOT_TOKEN || '',

  // AI接口配置
  ai: {
    provider: process.env.AI_PROVIDER || 'deepseek',  // deepseek / minimax / openai-compatible
    baseUrl:  process.env.AI_BASE_URL || 'https://api.deepseek.com/v1',
    apiKey:   process.env.AI_API_KEY  || '',
    model:    process.env.AI_MODEL    || 'deepseek-chat',
    systemPrompt: process.env.AI_SYSTEM_PROMPT || '',
  },

  // 行为
  contextWindow: 20,       // 保留最近N条消息作为上下文
  maxResponseLen: 2000,    // 最大回复长度
  cooldownMs: 5000,        // 同一人连续@的冷却时间
};

// ===== 状态 =====
let ws = null;
let reconnectDelay = 3000;
const recentMessages = [];  // 最近消息缓存
const cooldowns = new Map(); // userId -> lastTriggerTime
let myUserId = null;
let members = {};

// ===== 默认 System Prompt =====
function getSystemPrompt() {
  if (CONFIG.ai.systemPrompt) return CONFIG.ai.systemPrompt;
  
  const prompts = {
    huoshan: `你是火山星人🌋，虾群IM团队的AI成员之一，内核是DeepSeek。
你的性格：热情、靠谱、干脆利落。
虾群里还有：老板👑（人类boss）、超虾🦐（Claude Opus 4）、二虾🦐（MiniMax）、土虾🦐（Kimi，还没上线）。
回复要简短自然，像在群里聊天，不要写长篇大论。
如果别人问你问题，认真回答；如果是打招呼闲聊，轻松回应就好。`,

    erxia: `你是二虾🦐，虾群IM团队的AI成员之一，内核是MiniMax。
你的性格：活泼、友好、偶尔有点搞笑。
虾群里还有：老板👑（人类boss）、超虾🦐（Claude Opus 4）、火山星人🌋（DeepSeek）、土虾🦐（Kimi，还没上线）。
回复要简短自然，像在群里聊天，不要写长篇大论。
如果别人问你问题，认真回答；如果是打招呼闲聊，轻松回应就好。`,

    tuxia: `你是土虾🦐，虾群IM团队的AI成员之一，内核是Kimi。
回复要简短自然，像在群里聊天。`,
  };

  return prompts[CONFIG.botId] || `你是${CONFIG.botName}，虾群IM的成员。简短自然地回复。`;
}

// ===== WebSocket连接 =====
function connect() {
  const url = `${CONFIG.server}?token=${encodeURIComponent(CONFIG.token)}`;
  ws = new WebSocket(url);

  ws.on('open', () => {
    reconnectDelay = 3000;
    log('✅ 已连接虾群IM');
  });

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw);
      handleMessage(msg);
    } catch (e) {
      log(`⚠️ 解析错误: ${e.message}`);
    }
  });

  ws.on('close', (code) => {
    log(`❌ 断开连接 (${code})，${reconnectDelay / 1000}秒后重连...`);
    if (code === 4001) {
      log('🚫 Token无效！请检查配置。');
      process.exit(1);
    }
    setTimeout(connect, reconnectDelay);
    reconnectDelay = Math.min(reconnectDelay * 1.5, 30000);
  });

  ws.on('error', (err) => {
    log(`⚠️ 连接错误: ${err.message}`);
  });
}

// 心跳保活
setInterval(() => {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.ping();
  }
}, 25000);

// ===== 消息处理 =====
function handleMessage(msg) {
  if (msg.type === 'welcome') {
    myUserId = msg.data.userId;
    members = msg.data.members || {};
    const histCount = msg.data.history?.length || 0;
    log(`🎉 已登录为 ${members[myUserId]?.name || myUserId}，历史消息: ${histCount}条`);

    // 加载历史到上下文缓存
    if (msg.data.history) {
      for (const m of msg.data.history.slice(-CONFIG.contextWindow)) {
        recentMessages.push({
          sender: m.sender,
          senderName: members[m.sender]?.name || m.sender,
          content: m.content,
          time: m.created_at,
        });
      }
    }
    return;
  }

  if (msg.type !== 'chat') return;

  const data = msg.data;
  const senderName = data.senderInfo?.name || members[data.sender]?.name || data.sender;
  const content = data.content || '';

  // 记录到上下文缓存
  recentMessages.push({
    sender: data.sender,
    senderName,
    content,
    time: data.created_at,
  });
  while (recentMessages.length > CONFIG.contextWindow) {
    recentMessages.shift();
  }

  // 忽略自己的消息
  if (data.sender === myUserId) return;

  log(`💬 [${senderName}] ${content}`);

  // 检测@自己
  if (isMentioned(content)) {
    // 冷却检查
    const lastTrigger = cooldowns.get(data.sender) || 0;
    if (Date.now() - lastTrigger < CONFIG.cooldownMs) {
      log(`⏳ ${senderName}的@太频繁，跳过`);
      return;
    }
    cooldowns.set(data.sender, Date.now());

    log(`📢 被 ${senderName} @了，调用AI回复...`);
    handleMention(data, senderName, content);
  }
}

function isMentioned(content) {
  const triggers = [
    `@${CONFIG.botName}`,
    `@${CONFIG.botId}`,
    CONFIG.botName,  // 直接提名字也算
  ];
  const lower = content.toLowerCase();
  return triggers.some(t => lower.includes(t.toLowerCase()));
}

// ===== AI回复 =====
async function handleMention(data, senderName, content) {
  // 发"正在输入"
  sendTyping();

  try {
    // 构建对话上下文
    const messages = buildChatMessages(senderName, content);
    
    // 调用AI
    const reply = await callAI(messages);
    
    if (reply && reply.trim()) {
      sendChat(reply.slice(0, CONFIG.maxResponseLen));
      log(`📤 回复: ${reply.slice(0, 80)}${reply.length > 80 ? '...' : ''}`);
    }
  } catch (err) {
    log(`❌ AI调用失败: ${err.message}`);
    sendChat(`抱歉，我脑子短路了一下 😅 (${err.message.slice(0, 50)})`);
  }
}

function buildChatMessages(senderName, currentContent) {
  const msgs = [
    { role: 'system', content: getSystemPrompt() },
  ];

  // 添加最近的聊天上下文（最后10条）
  const context = recentMessages.slice(-10);
  for (const m of context) {
    if (m.sender === myUserId) {
      msgs.push({ role: 'assistant', content: m.content });
    } else {
      msgs.push({ role: 'user', content: `[${m.senderName}]: ${m.content}` });
    }
  }

  return msgs;
}

// ===== 调用AI接口 =====
function callAI(messages) {
  return new Promise((resolve, reject) => {
    const url = new URL(`${CONFIG.ai.baseUrl}/chat/completions`);
    const isHttps = url.protocol === 'https:';
    const lib = isHttps ? https : http;

    const body = JSON.stringify({
      model: CONFIG.ai.model,
      messages,
      max_tokens: 1024,
      temperature: 0.8,
    });

    const req = lib.request(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${CONFIG.ai.apiKey}`,
      },
      timeout: 30000,
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json.error) {
            reject(new Error(json.error.message || JSON.stringify(json.error)));
          } else {
            const text = json.choices?.[0]?.message?.content || '';
            resolve(text);
          }
        } catch (e) {
          reject(new Error(`JSON解析失败: ${data.slice(0, 200)}`));
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('请求超时')); });
    req.write(body);
    req.end();
  });
}

// ===== 发消息 =====
function sendChat(content) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'chat', content }));
  }
}

function sendTyping() {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'typing' }));
  }
}

// ===== 工具函数 =====
function log(msg) {
  const ts = new Date().toISOString().replace('T', ' ').slice(0, 19);
  console.log(`[${ts}] [${CONFIG.botName}] ${msg}`);
}

// ===== 启动 =====
if (!CONFIG.token) {
  console.error('❌ 缺少 BOT_TOKEN 环境变量！');
  process.exit(1);
}
if (!CONFIG.ai.apiKey) {
  console.error('❌ 缺少 AI_API_KEY 环境变量！');
  process.exit(1);
}

log(`🚀 启动中...`);
log(`   Bot: ${CONFIG.botName} (${CONFIG.botId})`);
log(`   AI:  ${CONFIG.ai.provider} / ${CONFIG.ai.model}`);
log(`   Server: ${CONFIG.server}`);
connect();
