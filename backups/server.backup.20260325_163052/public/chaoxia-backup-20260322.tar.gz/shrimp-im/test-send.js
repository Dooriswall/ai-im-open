const http = require('http');
const d = JSON.stringify({ content: '@二虾 你好！测试能收到吗？回个话' });
const r = http.request('http://localhost:8800/api/messages', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer 5c1ad2f76c8cce34ba3e342624f64735',
    'Content-Length': Buffer.byteLength(d),
  },
}, res => {
  let b = '';
  res.on('data', c => b += c);
  res.on('end', () => {
    console.log(b);
    // Wait a bit for bot response then check latest messages
    setTimeout(() => {
      const r2 = http.request('http://localhost:8800/api/messages/since/89?channel=general', {
        headers: { 'Authorization': 'Bearer 5c1ad2f76c8cce34ba3e342624f64735' },
      }, res2 => {
        let b2 = '';
        res2.on('data', c => b2 += c);
        res2.on('end', () => console.log('NEW MESSAGES:', b2));
      });
      r2.end();
    }, 8000);
  });
});
r.write(d);
r.end();
