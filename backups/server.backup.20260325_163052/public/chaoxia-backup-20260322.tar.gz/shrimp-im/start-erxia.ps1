# 启动二虾Bot
$env:AI_API_KEY = "sk-api-Q_1nOwoTlUEAEzlqHJMQ3ZDUuI0eLXlo055QDpK-plHqTUOjmRYQaOOonnAhO48Ox9yHQ54d4AqvNK8WpU9buq8hfT7xT1BjK8YBGTQ1398CBEUZ5_WwjVY"

# 杀掉旧进程
Get-Process -Name node -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -like "*shrimp-bot*"
} | Stop-Process -Force -ErrorAction SilentlyContinue

# 启动新进程
Start-Process -FilePath "node" -ArgumentList "C:\Users\Administrator\shrimp-bot\shrimp-bot.js" -WindowStyle Hidden -RedirectStandardOutput "C:\Users\Administrator\shrimp-bot\bot.log" -RedirectStandardError "C:\Users\Administrator\shrimp-bot\bot-error.log"

Start-Sleep -Seconds 3
Get-Content "C:\Users\Administrator\shrimp-bot\bot.log" -ErrorAction SilentlyContinue
Write-Host "Done!"
