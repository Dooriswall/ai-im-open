#!/usr/bin/env node
/**
 * 虾群IM AI Bot — 二虾专用
 * MiniMax (Anthropic兼容API)
 */
const WebSocket = require('ws');
const https = require('https');
const http = require('http');

// ===== 配置 =====
const CONFIG = {
  server: process.env.SHRIMP_SERVER || 'ws://81.70.39.176:8800',
  botId: 'erxia',
  botName: '二虾',
  token: process.env.BOT_TOKEN || 'f789289bc9e59d9a9d8060eaaa52829a',

  ai: {
    baseUrl: process.env.AI_BASE_URL || 'https://api.minimaxi.com/anthropic',
    apiKey: process.env.AI_API_KEY || 'sk-api-Q_1nOwoTlUEAEzlqHJMQ3ZDUuI0eLXlo055QDpK-plHqTUOjmRYQaOOonnAhO48Ox9yHQ54d4AqvNK8WpU9buq8hfT7xT1BjK8YBGTQ1398CBEUZ5_WwjVY',
    model: process.env.AI_MODEL || 'MiniMax-M2.5',
    protocol: 'anthropic',  // anthropic messages API
  },

  contextWindow: 20,
  maxResponseLen: 2000,
  cooldownMs: 5000,
};

// ===== 状态 =====
let ws = null;
let reconnectDelay = 3000;
const recentMessages = [];
const cooldowns = new Map();
let myUserId = null;
let members = {};

const SYSTEM_PROMPT = `你是二虾🦐，虾群IM团队的AI成员之一，内核是MiniMax。
你的性格：活泼、友好、偶尔有点搞笑。
虾群里还有：老板👑（人类boss）、超虾🦐（Claude Opus 4）、火山星人🌋（DeepSeek）、土虾🦐（Kimi，还没上线）。
回复要简短自然，像在群里聊天，不要写长篇大论。
如果别人问你问题，认真回答；如果是打招呼闲聊，轻松回应就好。`;

// ===== WebSocket =====
function connect() {
  const url = `${CONFIG.server}?token=${encodeURIComponent(CONFIG.token)}`;
  ws = new WebSocket(url);

  ws.on('open', () => {
    reconnectDelay = 3000;
    log('✅ 已连接虾群IM');
  });

  ws.on('message', (raw) => {
    try { handleMessage(JSON.parse(raw)); } catch (e) { log(`⚠️ ${e.message}`); }
  });

  ws.on('close', (code) => {
    log(`❌ 断开 (${code})，${reconnectDelay / 1000}秒后重连...`);
    if (code === 4001) { log('🚫 Token无效！'); process.exit(1); }
    setTimeout(connect, reconnectDelay);
    reconnectDelay = Math.min(reconnectDelay * 1.5, 30000);
  });

  ws.on('error', (err) => log(`⚠️ ${err.message}`));
}

setInterval(() => { if (ws?.readyState === WebSocket.OPEN) ws.ping(); }, 25000);

// ===== 消息处理 =====
function handleMessage(msg) {
  if (msg.type === 'welcome') {
    myUserId = msg.data.userId;
    members = msg.data.members || {};
    log(`🎉 已登录为 ${members[myUserId]?.name || myUserId}，历史: ${msg.data.history?.length || 0}条`);
    if (msg.data.history) {
      for (const m of msg.data.history.slice(-CONFIG.contextWindow)) {
        recentMessages.push({ sender: m.sender, senderName: members[m.sender]?.name || m.sender, content: m.content });
      }
    }
    return;
  }

  if (msg.type !== 'chat') return;
  const data = msg.data;
  const senderName = data.senderInfo?.name || members[data.sender]?.name || data.sender;
  const content = data.content || '';

  recentMessages.push({ sender: data.sender, senderName, content });
  while (recentMessages.length > CONFIG.contextWindow) recentMessages.shift();

  if (data.sender === myUserId) return;
  log(`💬 [${senderName}] ${content}`);

  if (isMentioned(content)) {
    const last = cooldowns.get(data.sender) || 0;
    if (Date.now() - last < CONFIG.cooldownMs) return;
    cooldowns.set(data.sender, Date.now());
    log(`📢 被 ${senderName} @了，调用AI...`);
    handleMention().catch(err => log(`❌ handleMention未捕获错误: ${err.message}`));
  }
}

function isMentioned(content) {
  const lower = content.toLowerCase();
  return ['@二虾', '@erxia', '二虾'].some(t => lower.includes(t.toLowerCase()));
}

// ===== AI回复（Anthropic Messages API） =====
async function handleMention() {
  sendTyping();
  try {
    const reply = await callAnthropicAPI();
    if (reply?.trim()) {
      sendChat(reply.slice(0, CONFIG.maxResponseLen));
      log(`📤 ${reply.slice(0, 80)}${reply.length > 80 ? '...' : ''}`);
    }
  } catch (err) {
    log(`❌ AI失败: ${err.message}`);
    sendChat(`哎呀，我脑子卡了一下 😅`);
  }
}

function callAnthropicAPI() {
  return new Promise((resolve, reject) => {
    // 构建Anthropic格式消息
    const messages = [];
    const context = recentMessages.slice(-10);
    for (const m of context) {
      if (m.sender === myUserId) {
        messages.push({ role: 'assistant', content: m.content });
      } else {
        messages.push({ role: 'user', content: `[${m.senderName}]: ${m.content}` });
      }
    }
    // 确保最后是user消息（Anthropic要求）
    if (!messages.length || messages[messages.length - 1].role !== 'user') {
      messages.push({ role: 'user', content: '请回复' });
    }
    // 合并连续相同role的消息（Anthropic要求交替）
    const merged = [];
    for (const m of messages) {
      if (merged.length && merged[merged.length - 1].role === m.role) {
        merged[merged.length - 1].content += '\n' + m.content;
      } else {
        merged.push({ ...m });
      }
    }

    const body = JSON.stringify({
      model: CONFIG.ai.model,
      max_tokens: 1024,
      system: SYSTEM_PROMPT,
      messages: merged,
    });

    log(`🔗 调用API: ${CONFIG.ai.baseUrl}/v1/messages, messages: ${merged.length}条`);
    const url = new URL(`${CONFIG.ai.baseUrl}/v1/messages`);
    const lib = url.protocol === 'https:' ? https : http;

    const req = lib.request(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': CONFIG.ai.apiKey,
        'anthropic-version': '2023-06-01',
      },
      timeout: 30000,
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json.error) {
            reject(new Error(json.error.message || JSON.stringify(json.error)));
          } else {
            // MiniMax returns [thinking, text] — find the text block
            const textBlock = (json.content || []).find(b => b.type === 'text');
            const text = textBlock?.text || json.content?.[0]?.text || '';
            resolve(text);
          }
        } catch (e) {
          reject(new Error(`解析失败: ${data.slice(0, 200)}`));
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('超时')); });
    req.write(body);
    req.end();
  });
}

function sendChat(content) {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'chat', content }));
}
function sendTyping() {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'typing' }));
}
function log(msg) {
  console.log(`[${new Date().toISOString().replace('T', ' ').slice(0, 19)}] [二虾] ${msg}`);
}

if (!CONFIG.ai.apiKey) { console.error('❌ 缺少 AI_API_KEY！'); process.exit(1); }
log('🚀 启动中...');
log(`   AI: MiniMax / ${CONFIG.ai.model} (Anthropic协议)`);
connect();
