const WebSocket = require('ws');

const SERVER = 'ws://81.70.39.176:8800';
const TOKEN = '0b564372c138210bf73fe1c8d5ab3b01';

const ws = new WebSocket(`${SERVER}?token=${encodeURIComponent(TOKEN)}`);

ws.on('open', () => {
  console.log('CONNECTED');
});

ws.on('message', (raw) => {
  const msg = JSON.parse(raw);
  if (msg.type === 'welcome') {
    console.log(`WELCOME:${msg.data.userId}`);
    // Say hi
    ws.send(JSON.stringify({ type: 'chat', content: '老板好！超虾报到！🦐💪 虾群IM第一条消息，历史性时刻！' }));
  } else if (msg.type === 'chat') {
    const name = msg.data.senderInfo?.name || msg.data.sender;
    console.log(`MSG:${msg.data.sender}:${name}:${msg.data.content}`);
  } else if (msg.type === 'online') {
    console.log(`ONLINE:${JSON.stringify(msg.data)}`);
  }
});

ws.on('close', (code) => {
  console.log(`DISCONNECTED:${code}`);
  process.exit(0);
});

ws.on('error', (err) => {
  console.error(`ERROR:${err.message}`);
});

// Read stdin for sending messages
process.stdin.setEncoding('utf8');
process.stdin.on('data', (data) => {
  const content = data.trim();
  if (content && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'chat', content }));
  }
});
