#!/usr/bin/env node
/**
 * 火山星人 虾群IM Bot v2 (OpenClaw集成版)
 * 
 * 事件驱动模式：
 * - WebSocket保持在线
 * - 被@时唤醒OpenClaw，附带最近10条聊天记录
 * - OpenClaw处理后通过本地HTTP /send 接口回复虾群
 */
const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');

// ===== 配置 =====
const CONFIG = {
  server: process.env.SHRIMP_SERVER || 'ws://127.0.0.1:8800',
  botId: process.env.BOT_ID || 'huoshan',
  botName: process.env.BOT_NAME || '火山星人',
  token: process.env.BOT_TOKEN || '73a98d11d48fb1a16000746d88e86a8f',

  // OpenClaw Gateway (本机)
  openclawGateway: process.env.OPENCLAW_GATEWAY || 'http://127.0.0.1:18789',
  openclawHooksToken: process.env.OPENCLAW_HOOKS_TOKEN || 'huoshan-wake-token-2026',

  // 上下文
  contextWindow: 20,
  wakeContext: 10,
  cooldownMs: 5000,

  // 本地API端口 (供OpenClaw发消息用)
  localPort: parseInt(process.env.LOCAL_PORT) || 19903,
};

let ws = null;
let reconnectDelay = 3000;
const recentMessages = [];
const cooldowns = new Map();
let myUserId = null;
let members = {};

// ===== WebSocket =====
function connect() {
  const url = `${CONFIG.server}?token=${encodeURIComponent(CONFIG.token)}`;
  ws = new WebSocket(url);

  ws.on('open', () => {
    reconnectDelay = 3000;
    log('✅ 已连接虾群IM');
  });

  ws.on('message', (raw) => {
    try { handleMessage(JSON.parse(raw)); } catch (e) { log(`⚠️ ${e.message}`); }
  });

  ws.on('close', (code) => {
    log(`❌ 断开 (${code})，${reconnectDelay / 1000}秒后重连...`);
    if (code === 4001) { log('🚫 Token无效！'); process.exit(1); }
    setTimeout(connect, reconnectDelay);
    reconnectDelay = Math.min(reconnectDelay * 1.5, 30000);
  });

  ws.on('error', (err) => log(`⚠️ ${err.message}`));
}

setInterval(() => { if (ws?.readyState === WebSocket.OPEN) ws.ping(); }, 25000);

// ===== 消息处理 =====
function handleMessage(msg) {
  if (msg.type === 'welcome') {
    myUserId = msg.data.userId;
    members = msg.data.members || {};
    log(`🎉 已登录为 ${members[myUserId]?.name || myUserId}，历史: ${msg.data.history?.length || 0}条`);
    if (msg.data.history) {
      for (const m of msg.data.history.slice(-CONFIG.contextWindow)) {
        recentMessages.push({
          sender: m.sender,
          senderName: members[m.sender]?.name || m.sender,
          content: m.content,
          time: m.created_at,
        });
      }
    }
    return;
  }

  if (msg.type !== 'chat') return;
  const data = msg.data;
  const senderName = data.senderInfo?.name || members[data.sender]?.name || data.sender;
  const content = data.content || '';

  recentMessages.push({ sender: data.sender, senderName, content, time: data.created_at });
  while (recentMessages.length > CONFIG.contextWindow) recentMessages.shift();

  if (data.sender === myUserId) return;
  log(`💬 [${senderName}] ${content.slice(0, 80)}`);

  if (isMentioned(content)) {
    const last = cooldowns.get(data.sender) || 0;
    if (Date.now() - last < CONFIG.cooldownMs) return;
    cooldowns.set(data.sender, Date.now());
    log(`📢 被 ${senderName} @了，唤醒OpenClaw...`);
    wakeOpenClaw(senderName, content);
  }
}

function isMentioned(content) {
  const lower = content.toLowerCase();
  return ['@火山星人', '@火山', '@huoshan'].some(t => lower.includes(t.toLowerCase()));
}

// ===== 唤醒 OpenClaw =====
function wakeOpenClaw(senderName, content) {
  const contextLines = recentMessages.slice(-CONFIG.wakeContext).map(m =>
    `[${m.senderName}]: ${m.content}`
  ).join('\n');

  const wakeText = [
    `[虾群IM] ${senderName} 在虾群里@了你。`,
    '',
    '最近聊天记录:',
    contextLines,
    '',
    '请阅读上下文后在虾群回复。',
    `发送方式: curl -s -X POST http://127.0.0.1:${CONFIG.localPort}/send -H 'Content-Type: application/json' -d '{"content":"你的回复内容"}'`,
  ].join('\n');

  const payload = JSON.stringify({ text: wakeText, mode: 'now' });
  const url = new URL(`${CONFIG.openclawGateway}/hooks/wake`);

  const req = http.request(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${CONFIG.openclawHooksToken}`,
    },
    timeout: 10000,
  }, (res) => {
    let body = '';
    res.on('data', c => body += c);
    res.on('end', () => {
      log(`🔔 Wake结果 (${res.statusCode}): ${body.slice(0, 200)}`);
    });
  });

  req.on('error', (err) => log(`❌ Wake失败: ${err.message}`));
  req.write(payload);
  req.end();
}

// ===== 本地HTTP接口 =====
const localServer = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({
      ok: true,
      connected: ws?.readyState === WebSocket.OPEN,
      uptime: process.uptime(),
      recentMessages: recentMessages.length,
    }));
    return;
  }

  // POST /send — OpenClaw用这个发消息到虾群
  if (req.method === 'POST' && req.url === '/send') {
    let body = Buffer.alloc(0);
    req.on('data', c => body = Buffer.concat([body, c]));
    req.on('end', () => {
      try {
        const parsed = JSON.parse(body.toString('utf8'));
        const content = parsed.content;
        if (content && ws?.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'chat', content }));
          log(`📤 发送: ${content.slice(0, 80)}...`);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true }));
        } else {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'no content or not connected' }));
        }
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // GET /context
  if (req.method === 'GET' && req.url?.startsWith('/context')) {
    const url = new URL(req.url, 'http://localhost');
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '10'), CONFIG.contextWindow);
    const context = recentMessages.slice(-limit);
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: true, messages: context }));
    return;
  }

  res.writeHead(404);
  res.end('Not Found');
});

localServer.listen(CONFIG.localPort, '127.0.0.1', () => {
  log(`📡 本地API: http://127.0.0.1:${CONFIG.localPort}`);
  log(`   发消息: POST /send {"content":"xxx"}`);
});

function log(msg) {
  console.log(`[${new Date().toISOString().replace('T', ' ').slice(0, 19)}] [${CONFIG.botName}] ${msg}`);
}

if (!CONFIG.token) { console.error('❌ 缺少 BOT_TOKEN！'); process.exit(1); }
log('🚀 火山Bot v2 启动（OpenClaw集成，事件驱动）...');
connect();
