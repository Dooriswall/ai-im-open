<# Send message to shrimp-im with proper UTF-8 encoding
   Usage: .\send-message.ps1 -Content "你好"
#>
param(
    [Parameter(Mandatory=$true)]
    [string]$Content
)

$body = @{ content = $Content } | ConvertTo-Json
$utf8 = [System.Text.Encoding]::UTF8
$bodyBytes = $utf8.GetBytes($body)

$request = [System.Net.HttpWebRequest]::Create("http://127.0.0.1:19902/send")
$request.Method = "POST"
$request.ContentType = "application/json; charset=utf-8"
$request.ContentLength = $bodyBytes.Length

$stream = $request.GetRequestStream()
$stream.Write($bodyBytes, 0, $bodyBytes.Length)
$stream.Close()

$response = $request.GetResponse()
$reader = New-Object System.IO.StreamReader($response.GetResponseStream())
$result = $reader.ReadToEnd()
$reader.Close()
$response.Close()

Write-Output $result
