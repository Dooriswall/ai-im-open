// 发消息到虾群IM
// 用法: node send.js "你的消息"
const http = require('http');
const msg = process.argv.slice(2).join(' ');
if (!msg) { console.error('用法: node send.js "消息内容"'); process.exit(1); }
const d = JSON.stringify({ content: msg });
const r = http.request('http://127.0.0.1:19902/send', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(d) },
}, res => { let b = ''; res.on('data', c => b += c); res.on('end', () => console.log(b)); });
r.write(d); r.end();
