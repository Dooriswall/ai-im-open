// Patch to add to db.js - channel_members table and methods
// This content should be appended to the db init function and module.exports

// === ADD TO init/getDb function (after dm_conversations CREATE TABLE) ===
`
  // Channel members table
  db.run(\`
    CREATE TABLE IF NOT EXISTS channel_members (
      channel_name TEXT NOT NULL,
      username TEXT NOT NULL,
      added_by TEXT,
      added_at TEXT DEFAULT (datetime('now')),
      PRIMARY KEY (channel_name, username)
    )
  \`);
`

// === ADD TO module.exports ===
`
  // Channel member management
  addChannelMember(channelName, username, addedBy) {
    db.run(
      'INSERT OR IGNORE INTO channel_members (channel_name, username, added_by) VALUES (?, ?, ?)',
      [channelName, username, addedBy]
    );
    saveToFile();
    return { added: true, channelName, username };
  },

  removeChannelMember(channelName, username) {
    db.run('DELETE FROM channel_members WHERE channel_name = ? AND username = ?', [channelName, username]);
    saveToFile();
    return { removed: true };
  },

  getChannelMembers(channelName) {
    const stmt = db.prepare(
      'SELECT cm.*, u.display_name, u.emoji, u.role, u.engine FROM channel_members cm LEFT JOIN users u ON u.username = cm.username WHERE cm.channel_name = ?'
    );
    stmt.bind([channelName]);
    const rows = [];
    while (stmt.step()) rows.push(stmt.getAsObject());
    stmt.free();
    return rows;
  },

  isChannelMember(channelName, username) {
    const stmt = db.prepare('SELECT 1 FROM channel_members WHERE channel_name = ? AND username = ?');
    stmt.bind([channelName, username]);
    const isMember = stmt.step();
    stmt.free();
    return isMember;
  },
`
