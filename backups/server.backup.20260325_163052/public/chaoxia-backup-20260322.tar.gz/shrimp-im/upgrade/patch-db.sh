#!/bin/bash
cd ~/shrimp-im/server

# Add channel_members table creation to db.js (after dm_conversations table)
sed -i '/CREATE TABLE IF NOT EXISTS dm_conversations/,/);/{
/);/a\
  \n  // Channel members table\n  db.run(`\n    CREATE TABLE IF NOT EXISTS channel_members (\n      channel_name TEXT NOT NULL,\n      username TEXT NOT NULL,\n      added_by TEXT,\n      added_at TEXT DEFAULT (datetime('\''now'\'')),\n      PRIMARY KEY (channel_name, username)\n    )\n  `);
}' db.js

echo "DB table patch done"
