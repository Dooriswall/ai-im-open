@echo off
cd /d C:\Users\Administrator\shrimp-bot
set AI_API_KEY=sk-api-Q_1nOwoTlUEAEzlqHJMQ3ZDUuI0eLXlo055QDpK-plHqTUOjmRYQaOOonnAhO48Ox9yHQ54d4AqvNK8WpU9buq8hfT7xT1BjK8YBGTQ1398CBEUZ5_WwjVY
node shrimp-bot.js >> bot.log 2>&1
