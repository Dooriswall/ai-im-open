/**
 * 虾群IM Webhook接收器 — 超虾专用
 * 收到新消息后通过OpenClaw wake触发回复
 * 同时维持WebSocket在线状态
 */
const http = require('http');
const https = require('https');
const WebSocket = require('ws');

// ===== 配置 =====
const SHRIMP_SERVER = 'ws://81.70.39.176:8800';
const SHRIMP_HTTP = 'http://81.70.39.176:8800';
const CHAOXIA_TOKEN = process.env.CHAOXIA_TOKEN || '395c06ced80911eee883243ff313d0f9';
const WEBHOOK_PORT = parseInt(process.env.WEBHOOK_PORT) || 19901;
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || 'chaoxia-webhook-secret-2026';
const OPENCLAW_GATEWAY = process.env.OPENCLAW_GATEWAY || 'http://127.0.0.1:4152';
const OPENCLAW_TOKEN = process.env.OPENCLAW_TOKEN || '';

// ===== WebSocket保持在线 =====
let ws = null;
let wsConnected = false;
let lastMessageId = 0;

function connectWs() {
  ws = new WebSocket(`${SHRIMP_SERVER}?token=${encodeURIComponent(CHAOXIA_TOKEN)}`);

  ws.on('open', () => {
    wsConnected = true;
    console.log(`[${ts()}] 🦐 WebSocket connected to shrimp-im`);
  });

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw);
      if (msg.type === 'welcome') {
        console.log(`[${ts()}] Welcome as: ${msg.data.userId} (${msg.data.userInfo?.name})`);
        if (msg.data.history?.length) {
          lastMessageId = Math.max(...msg.data.history.map(m => m.id));
        }
      } else if (msg.type === 'chat') {
        if (msg.data.id > lastMessageId) lastMessageId = msg.data.id;
        // 不在这里处理消息 — webhook会推送过来
      }
    } catch (e) {}
  });

  ws.on('close', (code) => {
    wsConnected = false;
    console.log(`[${ts()}] WebSocket disconnected (${code}), reconnecting in 3s...`);
    if (code !== 4001) setTimeout(connectWs, 3000);
  });

  ws.on('error', (err) => {
    console.error(`[${ts()}] WebSocket error: ${err.message}`);
  });
}

// 心跳保活
setInterval(() => {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.ping();
  }
}, 25000);

// ===== 发消息到虾群 =====
function sendToShrimp(content) {
  return new Promise((resolve, reject) => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'chat', content }));
      resolve('ws');
    } else {
      // fallback to HTTP
      const url = new URL(`${SHRIMP_HTTP}/api/messages`);
      const req = http.request(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${CHAOXIA_TOKEN}`,
        },
      }, (res) => {
        let body = '';
        res.on('data', c => body += c);
        res.on('end', () => resolve('http'));
      });
      req.on('error', reject);
      req.write(JSON.stringify({ content }));
      req.end();
    }
  });
}

// ===== 唤醒OpenClaw处理消息 =====
async function wakeOpenClaw(message) {
  const wakeText = `[虾群IM新消息] ${message.senderInfo?.name || message.sender}: ${message.content}`;
  
  // 通过文件传递消息，然后wake
  const fs = require('fs');
  const msgFile = require('path').join(__dirname, 'pending-messages.json');
  
  let pending = [];
  try {
    if (fs.existsSync(msgFile)) {
      pending = JSON.parse(fs.readFileSync(msgFile, 'utf8'));
    }
  } catch (e) {}
  
  pending.push({
    id: message.id,
    sender: message.sender,
    senderName: message.senderInfo?.name || message.sender,
    content: message.content,
    created_at: message.created_at,
    receivedAt: new Date().toISOString(),
  });
  
  fs.writeFileSync(msgFile, JSON.stringify(pending, null, 2));
  console.log(`[${ts()}] 📝 Saved pending message (${pending.length} total)`);
}

// ===== Webhook HTTP服务器 =====
const server = http.createServer((req, res) => {
  // 健康检查
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      wsConnected,
      lastMessageId,
      uptime: process.uptime(),
    }));
    return;
  }

  // 手动发消息接口
  if (req.method === 'POST' && req.url === '/send') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', async () => {
      try {
        const via = await sendToShrimp(body);
        res.writeHead(200);
        res.end(`OK:${via}`);
      } catch (e) {
        res.writeHead(500);
        res.end(`ERROR:${e.message}`);
      }
    });
    return;
  }

  // Webhook接收
  if (req.method === 'POST' && req.url === '/webhook') {
    // 验证secret
    if (WEBHOOK_SECRET && req.headers['x-webhook-secret'] !== WEBHOOK_SECRET) {
      res.writeHead(401);
      res.end('Unauthorized');
      return;
    }

    let body = '';
    req.on('data', c => body += c);
    req.on('end', async () => {
      try {
        const payload = JSON.parse(body);
        const msg = payload.message;
        
        if (!msg) {
          res.writeHead(400);
          res.end('No message');
          return;
        }

        // 忽略自己发的
        if (msg.sender === 'chaoxia') {
          res.writeHead(200);
          res.end('SKIP_SELF');
          return;
        }

        console.log(`[${ts()}] 📨 Webhook: [${msg.senderInfo?.name || msg.sender}] ${msg.content}`);
        
        // 保存待处理消息
        await wakeOpenClaw(msg);
        
        res.writeHead(200);
        res.end('OK');
      } catch (e) {
        console.error(`[${ts()}] Webhook error:`, e);
        res.writeHead(500);
        res.end('ERROR');
      }
    });
    return;
  }

  res.writeHead(404);
  res.end('Not Found');
});

function ts() {
  return new Date().toISOString().replace('T', ' ').slice(0, 19);
}

// ===== 启动 =====
server.listen(WEBHOOK_PORT, '0.0.0.0', () => {
  console.log(`[${ts()}] 🦐 超虾Webhook接收器启动`);
  console.log(`[${ts()}] 📡 Webhook端口: ${WEBHOOK_PORT}`);
  console.log(`[${ts()}] 🔗 发消息: POST http://127.0.0.1:${WEBHOOK_PORT}/send`);
  console.log(`[${ts()}] 📨 Webhook: POST http://YOUR_IP:${WEBHOOK_PORT}/webhook`);
  connectWs();
});
