const WebSocket = require('ws');

const SERVER = 'ws://81.70.39.176:8800';
const TOKEN = process.argv[2] || '591d2ab22149c399e26b755053b96f12';
const GREETING = process.argv[3] || '';

let ws;
let connected = false;

function connect() {
  ws = new WebSocket(`${SERVER}?token=${encodeURIComponent(TOKEN)}`);

  ws.on('open', () => {
    connected = true;
    console.log('CONNECTED');
  });

  ws.on('message', (raw) => {
    const msg = JSON.parse(raw);
    if (msg.type === 'welcome') {
      console.log(`WELCOME:${msg.data.userId}:${msg.data.userInfo?.name}`);
      if (GREETING) {
        ws.send(JSON.stringify({ type: 'chat', content: GREETING }));
      }
    } else if (msg.type === 'chat') {
      const name = msg.data.senderInfo?.name || msg.data.sender;
      console.log(`MSG:${msg.data.sender}:${name}:${msg.data.content}`);
    } else if (msg.type === 'online') {
      const names = Object.values(msg.data).map(m => m.name).join(', ');
      console.log(`ONLINE:${names}`);
    }
  });

  ws.on('close', (code) => {
    connected = false;
    console.log(`DISCONNECTED:${code}`);
    if (code !== 4001) {
      setTimeout(connect, 3000);
    }
  });

  ws.on('error', (err) => {
    console.error(`ERROR:${err.message}`);
  });
}

// Keep process alive
setInterval(() => {
  if (connected && ws.readyState === WebSocket.OPEN) {
    ws.ping();
  }
}, 25000);

connect();

// Handle SEND commands via a simple HTTP server on a local port
const http = require('http');
const sendPort = parseInt(process.env.SEND_PORT) || 19900;
http.createServer((req, res) => {
  if (req.method === 'POST') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'chat', content: body }));
        res.writeHead(200);
        res.end('OK');
      } else {
        res.writeHead(503);
        res.end('NOT_CONNECTED');
      }
    });
  } else {
    res.writeHead(200);
    res.end(connected ? 'CONNECTED' : 'DISCONNECTED');
  }
}).listen(sendPort, '127.0.0.1', () => {
  console.log(`SEND_PORT:${sendPort}`);
});
