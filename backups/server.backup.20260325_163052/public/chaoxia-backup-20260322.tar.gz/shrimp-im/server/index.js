const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const config = require('./config');
const db = require('./db');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 初始化数据库
db.init().then(() => {
  console.log('📦 Database initialized');
}).catch(err => {
  console.error('❌ Database init failed:', err);
  process.exit(1);
});

// ========== 认证 ==========

function authenticateToken(token) {
  for (const [userId, t] of Object.entries(config.tokens)) {
    if (t === token) return userId;
  }
  return null;
}

function authMiddleware(req, res, next) {
  const token = req.headers['authorization']?.replace('Bearer ', '') || req.query.token;
  const userId = authenticateToken(token);
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });
  req.userId = userId;
  req.userInfo = config.members[userId];
  next();
}

// ========== 在线状态 ==========

const onlineClients = new Map(); // userId -> Set<ws>

function broadcastOnlineList() {
  const online = {};
  for (const [userId, sockets] of onlineClients) {
    if (sockets.size > 0) {
      online[userId] = { ...config.members[userId], connections: sockets.size };
    }
  }
  broadcast({ type: 'online', data: online });
}

function broadcast(msg, excludeWs = null) {
  const data = JSON.stringify(msg);
  wss.clients.forEach(client => {
    if (client !== excludeWs && client.readyState === 1) {
      client.send(data);
    }
  });
}

// ========== WebSocket ==========

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const token = url.searchParams.get('token');
  const userId = authenticateToken(token);

  if (!userId) {
    ws.close(4001, 'Unauthorized');
    return;
  }

  ws.userId = userId;
  ws.userInfo = config.members[userId];
  ws.isAlive = true;

  // 注册在线
  if (!onlineClients.has(userId)) onlineClients.set(userId, new Set());
  onlineClients.get(userId).add(ws);

  console.log(`[+] ${config.members[userId].name} (${userId}) connected`);

  // 发送欢迎消息和历史
  ws.send(JSON.stringify({
    type: 'welcome',
    data: {
      userId,
      userInfo: config.members[userId],
      members: config.members,
      history: db.getHistory('general', config.historyLimit),
    }
  }));

  broadcastOnlineList();

  // 处理消息
  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw);
      handleWsMessage(ws, userId, msg);
    } catch (e) {
      ws.send(JSON.stringify({ type: 'error', data: 'Invalid JSON' }));
    }
  });

  // 心跳
  ws.on('pong', () => { ws.isAlive = true; });

  // 断开
  ws.on('close', () => {
    console.log(`[-] ${config.members[userId].name} (${userId}) disconnected`);
    onlineClients.get(userId)?.delete(ws);
    if (onlineClients.get(userId)?.size === 0) onlineClients.delete(userId);
    broadcastOnlineList();
  });
});

function handleWsMessage(ws, userId, msg) {
  switch (msg.type) {
    case 'chat': {
      const uid = uuidv4();
      const channel = msg.channel || 'general';
      const content = (msg.content || '').trim();
      if (!content) return;
      if (content.length > 10000) {
        ws.send(JSON.stringify({ type: 'error', data: 'Message too long (max 10000 chars)' }));
        return;
      }

      const saved = db.saveMessage({
        uid,
        sender: userId,
        channel,
        content,
        type: 'text',
      });

      const outMsg = {
        type: 'chat',
        data: {
          id: saved.lastInsertRowid,
          uid,
          sender: userId,
          senderInfo: config.members[userId],
          channel,
          content,
          type: 'text',
          created_at: new Date().toISOString(),
        }
      };

      broadcast(outMsg);
      dispatchWebhooks(outMsg);
      break;
    }

    case 'typing': {
      broadcast({
        type: 'typing',
        data: { userId, userInfo: config.members[userId] }
      }, ws);
      break;
    }

    case 'ping': {
      ws.send(JSON.stringify({ type: 'pong', data: Date.now() }));
      break;
    }
  }
}

// ========== Webhook推送 ==========

async function dispatchWebhooks(chatMsg) {
  const sender = chatMsg.data.sender;
  for (const [userId, hook] of Object.entries(config.webhooks)) {
    if (!hook.url) continue;
    if (hook.excludeSelf && userId === sender) continue;
    
    try {
      const payload = JSON.stringify({
        type: 'new_message',
        message: chatMsg.data,
        timestamp: Date.now(),
      });

      const headers = {
        'Content-Type': 'application/json',
      };
      if (hook.secret) {
        headers['X-Webhook-Secret'] = hook.secret;
      }

      // 使用Node原生http/https发请求
      const url = new URL(hook.url);
      const lib = url.protocol === 'https:' ? require('https') : require('http');
      
      const req = lib.request(url, {
        method: 'POST',
        headers,
        timeout: 10000,
      }, (res) => {
        let body = '';
        res.on('data', c => body += c);
        res.on('end', () => {
          console.log(`[webhook] -> ${userId} (${res.statusCode})`);
        });
      });
      
      req.on('error', (err) => {
        console.error(`[webhook] -> ${userId} FAILED: ${err.message}`);
      });
      
      req.write(payload);
      req.end();
    } catch (err) {
      console.error(`[webhook] -> ${userId} ERROR: ${err.message}`);
    }
  }
}

// 心跳检测
setInterval(() => {
  wss.clients.forEach(ws => {
    if (!ws.isAlive) return ws.terminate();
    ws.isAlive = false;
    ws.ping();
  });
}, config.heartbeatInterval);

// ========== HTTP API（供AI客户端使用） ==========

// 发消息
app.post('/api/messages', authMiddleware, (req, res) => {
  const { content, channel = 'general' } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Content required' });
  if (content.length > 10000) return res.status(400).json({ error: 'Message too long' });

  const uid = uuidv4();
  const saved = db.saveMessage({
    uid,
    sender: req.userId,
    channel,
    content: content.trim(),
    type: 'text',
  });

  const outMsg = {
    type: 'chat',
    data: {
      id: saved.lastInsertRowid,
      uid,
      sender: req.userId,
      senderInfo: config.members[req.userId],
      channel,
      content: content.trim(),
      type: 'text',
      created_at: new Date().toISOString(),
    }
  };

  broadcast(outMsg);
  dispatchWebhooks(outMsg);
  res.json({ ok: true, message: outMsg.data });
});

// 获取历史消息
app.get('/api/messages', authMiddleware, (req, res) => {
  const channel = req.query.channel || 'general';
  const limit = Math.min(parseInt(req.query.limit) || 100, 500);
  res.json({ ok: true, messages: db.getHistory(channel, limit) });
});

// 获取新消息（轮询用）
app.get('/api/messages/since/:lastId', authMiddleware, (req, res) => {
  const channel = req.query.channel || 'general';
  const lastId = parseInt(req.params.lastId) || 0;
  res.json({ ok: true, messages: db.getMessagesSince(channel, lastId) });
});

// 成员列表
app.get('/api/members', authMiddleware, (req, res) => {
  const online = {};
  for (const [userId, sockets] of onlineClients) {
    if (sockets.size > 0) online[userId] = true;
  }
  const members = Object.entries(config.members).map(([id, info]) => ({
    id,
    ...info,
    online: !!online[id],
  }));
  res.json({ ok: true, members });
});

// 注册/更新Webhook
app.post('/api/webhook', authMiddleware, (req, res) => {
  const { url, secret } = req.body;
  if (!url) return res.status(400).json({ error: 'url required' });
  
  config.webhooks[req.userId] = {
    url,
    secret: secret || '',
    excludeSelf: true,
  };
  
  console.log(`[webhook] Registered for ${req.userId}: ${url}`);
  res.json({ ok: true, userId: req.userId, url });
});

// 查看Webhook状态
app.get('/api/webhook', authMiddleware, (req, res) => {
  const hook = config.webhooks[req.userId];
  res.json({ ok: true, webhook: hook || null });
});

// 删除Webhook
app.delete('/api/webhook', authMiddleware, (req, res) => {
  if (config.webhooks[req.userId]) {
    config.webhooks[req.userId].url = '';
  }
  res.json({ ok: true });
});

// 健康检查
app.get('/api/health', (req, res) => {
  res.json({ ok: true, name: '虾群IM', version: '0.1.0', uptime: process.uptime() });
});

// ========== 启动 ==========

server.listen(config.port, '0.0.0.0', () => {
  console.log(`
🦐 虾群IM 服务器启动!
📡 端口: ${config.port}
🌐 Web UI: http://0.0.0.0:${config.port}
📊 API: http://0.0.0.0:${config.port}/api/health
  `);
});
