const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');
const config = require('./config');

let db = null;

async function getDb() {
  if (db) return db;
  
  const SQL = await initSqlJs();
  const dbPath = config.dbPath;
  
  // 如果数据库文件存在，加载它
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
  }

  // 建表
  db.run(`
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uid TEXT NOT NULL,
      sender TEXT NOT NULL,
      channel TEXT NOT NULL DEFAULT 'general',
      content TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'text',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      metadata TEXT
    )
  `);
  db.run(`CREATE INDEX IF NOT EXISTS idx_messages_channel ON messages(channel, created_at)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender)`);
  db.run(`
    CREATE TABLE IF NOT EXISTS channels (
      name TEXT PRIMARY KEY,
      description TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);
  db.run(`INSERT OR IGNORE INTO channels (name, description) VALUES ('general', '虾群大厅 - 所有人的公共频道')`);
  
  saveToFile();
  return db;
}

function saveToFile() {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(config.dbPath, buffer);
}

// 定期保存到磁盘
setInterval(() => {
  saveToFile();
}, 10000);

module.exports = {
  async init() {
    return getDb();
  },

  saveMessage({ uid, sender, channel = 'general', content, type = 'text', metadata = null }) {
    db.run(
      `INSERT INTO messages (uid, sender, channel, content, type, metadata) VALUES (?, ?, ?, ?, ?, ?)`,
      [uid, sender, channel, content, type, metadata ? JSON.stringify(metadata) : null]
    );
    saveToFile();
    // 获取最后插入的ID
    const result = db.exec(`SELECT last_insert_rowid() as id`);
    return { lastInsertRowid: result[0].values[0][0] };
  },

  getHistory(channel = 'general', limit = 200) {
    const stmt = db.prepare(`SELECT * FROM messages WHERE channel = ? ORDER BY id DESC LIMIT ?`);
    stmt.bind([channel, limit]);
    const rows = [];
    while (stmt.step()) {
      rows.push(stmt.getAsObject());
    }
    stmt.free();
    return rows.reverse();
  },

  getMessagesSince(channel = 'general', lastId = 0) {
    const stmt = db.prepare(`SELECT * FROM messages WHERE channel = ? AND id > ? ORDER BY id ASC`);
    stmt.bind([channel, lastId]);
    const rows = [];
    while (stmt.step()) {
      rows.push(stmt.getAsObject());
    }
    stmt.free();
    return rows;
  },
};
