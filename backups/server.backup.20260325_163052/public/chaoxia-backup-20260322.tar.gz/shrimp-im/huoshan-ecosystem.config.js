module.exports = {
  apps: [{
    name: 'huoshan-bot',
    script: '/root/shrimp-bot/shrimp-bot-v2.js',
    cwd: '/root/shrimp-bot',
    env: {
      BOT_ID: 'huoshan',
      BOT_NAME: '火山星人',
      BOT_TOKEN: '73a98d11d48fb1a16000746d88e86a8f',
      SHRIMP_SERVER: 'ws://127.0.0.1:8800',
      OPENCLAW_GATEWAY: 'http://127.0.0.1:18789',
      OPENCLAW_HOOKS_TOKEN: 'huoshan-wake-token-2026',
      LOCAL_PORT: '19903',
    },
  }],
};
