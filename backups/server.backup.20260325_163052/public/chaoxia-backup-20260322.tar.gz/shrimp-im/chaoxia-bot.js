#!/usr/bin/env node
/**
 * 超虾 虾群IM Bot v2
 * 
 * 事件驱动模式：
 * - WebSocket保持在线
 * - 被@时唤醒OpenClaw，附带最近10条聊天记录
 * - OpenClaw通过本地HTTP /send 接口回复
 * - 不需要轮询，不需要cron
 */
const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');

// ===== 配置 =====
const CONFIG = {
  server: process.env.SHRIMP_SERVER || 'ws://81.70.39.176:8800',
  botId: 'chaoxia',
  botName: '超虾',
  token: process.env.BOT_TOKEN || '395c06ced80911eee883243ff313d0f9',

  // OpenClaw Gateway (webhook hooks endpoint)
  openclawGateway: process.env.OPENCLAW_GATEWAY || 'http://127.0.0.1:18789',
  openclawHooksToken: process.env.OPENCLAW_HOOKS_TOKEN || 'chaoxia-wake-token-2026',

  // 上下文窗口
  contextWindow: 20,    // 内存中保留的消息数
  wakeContext: 10,      // wake时附带的最近消息数

  // 冷却时间（防止短时间内重复触发）
  cooldownMs: 5000,

  // 本地API端口
  localPort: parseInt(process.env.LOCAL_PORT) || 19902,
};

let ws = null;
let reconnectDelay = 3000;
const recentMessages = [];
const cooldowns = new Map();
let myUserId = null;
let members = {};

// ===== WebSocket =====
function connect() {
  const url = `${CONFIG.server}?token=${encodeURIComponent(CONFIG.token)}`;
  ws = new WebSocket(url);

  ws.on('open', () => {
    reconnectDelay = 3000;
    log('✅ 已连接虾群IM');
  });

  ws.on('message', (raw) => {
    try { handleMessage(JSON.parse(raw)); } catch (e) { log(`⚠️ ${e.message}`); }
  });

  ws.on('close', (code) => {
    log(`❌ 断开 (${code})，${reconnectDelay / 1000}秒后重连...`);
    if (code === 4001) { log('🚫 Token无效！'); process.exit(1); }
    setTimeout(connect, reconnectDelay);
    reconnectDelay = Math.min(reconnectDelay * 1.5, 30000);
  });

  ws.on('error', (err) => log(`⚠️ ${err.message}`));
}

// 心跳保活
setInterval(() => { if (ws?.readyState === WebSocket.OPEN) ws.ping(); }, 25000);

// ===== 消息处理 =====
function handleMessage(msg) {
  if (msg.type === 'welcome') {
    myUserId = msg.data.userId;
    members = msg.data.members || {};
    log(`🎉 已登录为 ${members[myUserId]?.name || myUserId}，历史: ${msg.data.history?.length || 0}条`);
    // 加载历史消息到内存
    if (msg.data.history) {
      for (const m of msg.data.history.slice(-CONFIG.contextWindow)) {
        recentMessages.push({
          sender: m.sender,
          senderName: members[m.sender]?.name || m.sender,
          content: m.content,
          time: m.created_at,
        });
      }
    }
    return;
  }

  if (msg.type !== 'chat') return;
  const data = msg.data;
  const senderName = data.senderInfo?.name || members[data.sender]?.name || data.sender;
  const content = data.content || '';

  // 记录到内存
  recentMessages.push({
    sender: data.sender,
    senderName,
    content,
    time: data.created_at,
  });
  while (recentMessages.length > CONFIG.contextWindow) recentMessages.shift();

  // 忽略自己发的消息
  if (data.sender === myUserId) return;

  log(`💬 [${senderName}] ${content.slice(0, 80)}`);

  // 检测@超虾
  if (isMentioned(content)) {
    const last = cooldowns.get(data.sender) || 0;
    if (Date.now() - last < CONFIG.cooldownMs) {
      log(`⏳ ${senderName} 冷却中，跳过`);
      return;
    }
    cooldowns.set(data.sender, Date.now());
    log(`📢 被 ${senderName} @了，唤醒OpenClaw...`);
    wakeOpenClaw(senderName, content);
  }
}

function isMentioned(content) {
  const lower = content.toLowerCase();
  return ['@超虾', '@chaoxia'].some(t => lower.includes(t.toLowerCase()));
}

// ===== 唤醒 OpenClaw =====
function wakeOpenClaw(senderName, content) {
  // 构建最近N条聊天记录作为上下文
  const contextLines = recentMessages.slice(-CONFIG.wakeContext).map(m =>
    `[${m.senderName}]: ${m.content}`
  ).join('\n');

  const wakeText = [
    `[虾群IM] ${senderName} 在虾群里@了你。`,
    '',
    '最近聊天记录:',
    contextLines,
    '',
    '请阅读上下文后在虾群回复。',
    '发送方式: 执行 shrimp-im/send-message.ps1 -Content "你的回复"',
  ].join('\n');

  // 同时写入pending（备用）
  writePending(senderName, content);

  // Wake OpenClaw via webhook hooks endpoint
  const payload = JSON.stringify({ text: wakeText, mode: 'now' });
  const url = new URL(`${CONFIG.openclawGateway}/hooks/wake`);

  const req = http.request(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${CONFIG.openclawHooksToken}`,
    },
    timeout: 10000,
  }, (res) => {
    let body = '';
    res.on('data', c => body += c);
    res.on('end', () => {
      log(`🔔 Wake结果 (${res.statusCode}): ${body.slice(0, 200)}`);
    });
  });

  req.on('error', (err) => log(`❌ Wake失败: ${err.message}`));
  req.write(payload);
  req.end();
}

function writePending(senderName, content) {
  const pendingFile = path.join(__dirname, 'pending-messages.json');
  let pending = [];
  try {
    if (fs.existsSync(pendingFile)) pending = JSON.parse(fs.readFileSync(pendingFile, 'utf8'));
  } catch (e) {}
  pending.push({
    id: 0,
    sender: 'unknown',
    senderName,
    content,
    created_at: new Date().toISOString(),
    receivedAt: new Date().toISOString(),
  });
  fs.writeFileSync(pendingFile, JSON.stringify(pending, null, 2));
}

// ===== 本地HTTP接口 =====
const localServer = http.createServer((req, res) => {
  // 健康检查
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({
      ok: true,
      connected: ws?.readyState === WebSocket.OPEN,
      uptime: process.uptime(),
      recentMessages: recentMessages.length,
    }));
    return;
  }

  // POST /send — OpenClaw用这个发消息到虾群
  if (req.method === 'POST' && req.url === '/send') {
    let body = Buffer.alloc(0);
    req.on('data', c => body = Buffer.concat([body, c]));
    req.on('end', () => {
      try {
        const parsed = JSON.parse(body.toString('utf8'));
        const content = parsed.content;
        if (content && ws?.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'chat', content }));
          log(`📤 发送: ${content.slice(0, 80)}...`);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: true }));
        } else {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ ok: false, error: 'no content or not connected' }));
        }
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: e.message }));
      }
    });
    return;
  }

  // GET /pending — 查看待处理消息
  if (req.method === 'GET' && req.url === '/pending') {
    const pendingFile = path.join(__dirname, 'pending-messages.json');
    try {
      const data = fs.existsSync(pendingFile) ? fs.readFileSync(pendingFile, 'utf8') : '[]';
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(data);
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: e.message }));
    }
    return;
  }

  // DELETE /pending — 清空待处理
  if (req.method === 'DELETE' && req.url === '/pending') {
    const pendingFile = path.join(__dirname, 'pending-messages.json');
    fs.writeFileSync(pendingFile, '[]');
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true }));
    return;
  }

  // GET /context — 获取最近N条消息上下文
  if (req.method === 'GET' && req.url?.startsWith('/context')) {
    const url = new URL(req.url, 'http://localhost');
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '10'), CONFIG.contextWindow);
    const context = recentMessages.slice(-limit);
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify({ ok: true, messages: context }));
    return;
  }

  res.writeHead(404);
  res.end('Not Found');
});

localServer.listen(CONFIG.localPort, '127.0.0.1', () => {
  log(`📡 本地API: http://127.0.0.1:${CONFIG.localPort}`);
  log(`   发消息: POST /send {"content":"xxx"}`);
  log(`   上下文: GET /context?limit=10`);
  log(`   待处理: GET /pending`);
});

function log(msg) {
  console.log(`[${new Date().toISOString().replace('T', ' ').slice(0, 19)}] [超虾] ${msg}`);
}

if (!CONFIG.token) { console.error('❌ 缺少 BOT_TOKEN！'); process.exit(1); }
log('🚀 超虾Bot v2 启动（事件驱动模式，无轮询）...');
connect();
