const https = require('https');

const API_KEY = 'sk-api-Q_1nOwoTlUEAEzlqHJMQ3ZDUuI0eLXlo055QDpK-plHqTUOjmRYQaOOonnAhO48Ox9yHQ54d4AqvNK8WpU9buq8hfT7xT1BjK8YBGTQ1398CBEUZ5_WwjVY';

const body = JSON.stringify({
  model: 'MiniMax-M2.5',
  max_tokens: 256,
  system: 'You are a helpful assistant.',
  messages: [{ role: 'user', content: 'Say hello in Chinese, keep it short' }],
});

// Try the Anthropic-compatible endpoint
const url = new URL('https://api.minimaxi.com/anthropic/v1/messages');
console.log('Requesting:', url.href);

const req = https.request(url, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-api-key': API_KEY,
    'anthropic-version': '2023-06-01',
  },
  timeout: 15000,
}, (res) => {
  console.log('Status:', res.statusCode);
  let data = '';
  res.on('data', c => data += c);
  res.on('end', () => {
    console.log('Response:', data.slice(0, 500));
  });
});

req.on('error', e => console.log('Error:', e.message));
req.on('timeout', () => { console.log('TIMEOUT'); req.destroy(); });
req.write(body);
req.end();
