#!/bin/bash
# =============================================
# 虾群IM 部署脚本 — 在火山星人服务器上运行
# Ubuntu Server 24.04 LTS
# =============================================

set -e

echo "🦐 虾群IM 部署开始..."

# 1. 创建项目目录
PROJECT_DIR="$HOME/shrimp-im"
mkdir -p "$PROJECT_DIR/server/public"
echo "📁 项目目录: $PROJECT_DIR"

# 2. 安装依赖（如果没有的话）
if ! command -v pm2 &> /dev/null; then
    echo "📦 安装 pm2..."
    npm install -g pm2
fi

# 3. 进入目录安装依赖
cd "$PROJECT_DIR/server"
echo "📦 安装 Node.js 依赖..."
npm install

# 4. 生成安全的Token（如果config里还是默认值就替换）
echo ""
echo "============================================"
echo "🔑 Token 信息 (请保存好！)"
echo "============================================"

# 用随机值生成token
BOSS_TOKEN=$(openssl rand -hex 16)
CHAOXIA_TOKEN=$(openssl rand -hex 16)
HUOSHAN_TOKEN=$(openssl rand -hex 16)
ERXIA_TOKEN=$(openssl rand -hex 16)
TUXIA_TOKEN=$(openssl rand -hex 16)

echo "老板:     $BOSS_TOKEN"
echo "超虾:     $CHAOXIA_TOKEN"
echo "火山星人: $HUOSHAN_TOKEN"
echo "二虾:     $ERXIA_TOKEN"
echo "土虾:     $TUXIA_TOKEN"
echo "============================================"
echo ""

# 5. 创建环境变量文件
cat > "$PROJECT_DIR/server/.env" << EOF
SHRIMP_PORT=8800
TOKEN_BOSS=$BOSS_TOKEN
TOKEN_CHAOXIA=$CHAOXIA_TOKEN
TOKEN_HUOSHAN=$HUOSHAN_TOKEN
TOKEN_ERXIA=$ERXIA_TOKEN
TOKEN_TUXIA=$TUXIA_TOKEN
SHRIMP_DB=$PROJECT_DIR/server/shrimp-im.db
EOF

echo "📝 环境变量已写入 .env"

# 6. 用 pm2 启动（带环境变量）
cd "$PROJECT_DIR/server"
pm2 delete shrimp-im 2>/dev/null || true

# 加载.env并启动
set -a
source .env
set +a

pm2 start index.js --name shrimp-im --env production
pm2 save

echo ""
echo "============================================"
echo "🦐 虾群IM 部署完成!"
echo "🌐 Web UI: http://81.70.39.176:8800"
echo "📊 API:    http://81.70.39.176:8800/api/health"
echo "📋 日志:   pm2 logs shrimp-im"
echo "🔄 重启:   pm2 restart shrimp-im"
echo "============================================"
