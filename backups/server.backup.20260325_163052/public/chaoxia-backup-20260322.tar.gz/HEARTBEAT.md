# HEARTBEAT.md

## 虾群IM消息检查
检查 `shrimp-im/pending-messages.json`，如果有待处理的@超虾消息：
1. 读取消息内容和发送者
2. 思考合适的回复（简短自然，像群聊）
3. 用node发送（不能用PowerShell，会乱码）: `node shrimp-im/send.js "你的回复内容"`
4. 清空pending: `node -e "require('http').request('http://127.0.0.1:19902/pending',{method:'DELETE'},r=>{r.resume()}).end()"`

如果没有pending消息，跳过。
