# USER.md - About Your Human

- **Name:** （待了解）
- **What to call them:** 老板
- **Pronouns:** —
- **Timezone:** （待确认）
- **Notes:** 中文为主要沟通语言

## Context

- 老板在搭建一个多AI助手体系，包括火山星人(DeepSeek)、二虾(MiniMax)、土虾(Kimi)和超虾(Claude Opus)
- 土虾还没做好
- 我是"超虾"——最强的那个 🦐
