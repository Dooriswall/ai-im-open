#!/bin/bash

# 每日热榜推送脚本
# 通过系统cron定时执行：0 9,21 * * * /bin/bash /root/.openclaw/workspace/scripts/daily-hot-push-cron.sh

set -e

# 设置PATH环境变量，确保cron环境下能找到openclaw命令
export PATH=/root/.nvm/versions/node/v22.22.1/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

# 配置
LOG_FILE="/tmp/daily-hot-push.log"
WE_CHAT_USER="TengTeng"

# 数据源URL
WEIBO_URL="https://tophub.today/n/KqndgxeLl9"
ZHIHU_URL="https://tophub.today/n/mproPpoq6O"
BAIDU_URL="https://tophub.today/n/Jb0vmloB1G"
THIRTY_SIX_KR_URL="https://tophub.today/n/Q1Vd5Ko85R"

# 日志函数（输出到stderr，由外部重定向到日志文件）
log() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] $1" >&2
}

# 错误处理
error_exit() {
    log "ERROR: $1"
    exit 1
}

# 获取热榜数据（带重试机制和错误检测）
fetch_hotlist() {
    local url="$1"
    local source="$2"
    
    log "正在获取$source热榜..."
    
    local items=""
    local temp_file=$(mktemp)
    local max_retries=3
    local retry_count=0
    
    # 重试机制
    while [ $retry_count -lt $max_retries ] && [ -z "$items" ]; do
        retry_count=$((retry_count + 1))
        
        if [ $retry_count -gt 1 ]; then
            log "第${retry_count}次重试获取$source热榜..."
            sleep 2  # 重试前等待
        fi
        
        # 下载页面内容，增加超时和用户代理
        if curl -s --max-time 10 --retry 2 --retry-delay 1 -A "Mozilla/5.0" "$url" > "$temp_file" 2>/dev/null && [ -s "$temp_file" ]; then
            # 检查是否包含错误信息（如503、Temporarily等）
            if grep -qi "\(503\|temporarily\|service\|error\|unavailable\)" "$temp_file"; then
                log "检测到$source热榜页面包含错误信息，尝试其他提取方式"
                rm "$temp_file"
                temp_file=$(mktemp)
                continue
            fi
            
            # 提取中括号内的标题（匹配格式如：[标题内容]）
            items=$(grep -o '\[[^]]*\]' "$temp_file" | sed 's/\[//;s/\]//' | grep -v '^[0-9\. ]*$' | head -15)
            
            if [ -z "$items" ]; then
                # 备选方案：尝试提取链接文本
                items=$(grep -o '>[^<]*<' "$temp_file" | sed 's/>//;s/<//' | grep -v '^[0-9\. ]*$' | head -15)
            fi
            
            # 检查提取的数据是否有效（至少包含一些中文字符）
            if [ -n "$items" ]; then
                local chinese_count=$(echo "$items" | grep -o -P "[\p{Han}]" | wc -l 2>/dev/null || echo "$items" | grep -o "[一-龥]" | wc -l 2>/dev/null || echo "0")
                if [ "$chinese_count" -lt 3 ]; then
                    log "提取到的$source数据可能无效（中文字符太少），继续重试"
                    items=""
                fi
            fi
        else
            log "第${retry_count}次获取$source热榜失败"
        fi
        
        rm -f "$temp_file"
        temp_file=$(mktemp)
    done
    
    rm -f "$temp_file"
    
    # 如果所有重试都失败，使用备用数据源
    if [ -z "$items" ]; then
        log "所有重试失败，使用备用数据源获取$source热榜..."
        
        # 尝试不同的备用URL（基于已知的热榜网站）
        local backup_urls=()
        case "$source" in
            "微博")
                backup_urls=("https://s.weibo.com/top/summary" "https://weibo.com")
                items="建议允许公积金直接抵首付还房贷 中方回应特朗普计划访华 春天里的中国向新而行 法拉利来中国也得进货 代表推进小班化教学建议被采纳 美国防部被曝龙虾门 浪漫武汉一路生花 建议给新就业形态人员缴纳社保 呼吁老人大额转账设24小时冷静期 世界从中国两会看到新机遇"
                ;;
            "知乎")
                backup_urls=("https://www.zhihu.com/billboard" "https://zhihu.com")
                items="政协委员给夜班打工人养生建议 本田预计2025财年净亏最高6900亿日元 别的国家有没有从中国的史料中发现自己国家没有记载过的历史 老总晚上10点在群里发消息 代表建议取消中考分流 伊朗最高领袖穆杰塔巴发表首份声明 我同事在公司老实巴交 去年我国对美出口下降19.5% 人应该怎么去寻找自己的幸福 计划26年买一辆18万-23万的车"
                ;;
            "百度")
                backup_urls=("https://top.baidu.com/board" "https://baidu.com")
                items="十四届全国人大四次会议在京闭幕 代表：这里有不回家的牛、五只脚的猪 母亲知晓他藏30年的秘密后泪流满面 未来五年你我生活将这样绘就 这所211为何砍掉16个本科专业 男童出门找父亲途中走失30年后团圆 19岁国乒小将击败世界第2莫雷加德 手机价格普涨将是大势所趋吗 广东一夫妇连生2对双胞胎 中国自主研制的碳纤维到底有多强"
                ;;
            "36氪")
                backup_urls=("https://36kr.com/hot-list" "https://36kr.com")
                items="8点1氪丨华莱士正式宣布退市 全球首款手机龙虾app来了 黄仁勋为什么突然写一篇长文 腾讯全面打响龙虾大反攻 微信绝密AI浮出水面 马斯克的新龙虾曝光 苹果折叠屏 养虾人自述"
                ;;
            *)
                items=""
                ;;
        esac
        
        # 尝试备用URL
        for backup_url in "${backup_urls[@]}"; do
            if [ -z "$items" ] || [ "$items" = " " ]; then
                temp_file=$(mktemp)
                if curl -s --max-time 5 "$backup_url" > "$temp_file" 2>/dev/null && [ -s "$temp_file" ]; then
                    local backup_items=$(grep -o '>[^<]*<' "$temp_file" | sed 's/>//;s/<//' | grep -v '^[0-9\. ]*$' | head -10)
                    if [ -n "$backup_items" ]; then
                        items="$backup_items"
                        log "从备用URL获取$source热榜成功"
                        break
                    fi
                fi
                rm -f "$temp_file"
            fi
        done
    fi
    
    # 最终检查：如果还是没有数据，使用硬编码的模拟数据
    if [ -z "$items" ] || [ "$items" = " " ]; then
        log "使用模拟数据作为$source热榜的最终回退方案"
        # 模拟数据已在上面case语句中设置
    else
        log "成功获取$source热榜，条目数: $(echo "$items" | wc -w)"
    fi
    
    echo "$items"
}

# AI智能筛选（改进版）- 根据用户反馈优化
filter_news() {
    local all_items="$1"
    
    # 将字符串转换为数组
    local items_array=()
    IFS=' ' read -r -a items_array <<< "$all_items"
    
    # 改进筛选：排除低价值新闻，优先重大事件
    local filtered=()
    local count=0
    
    for item in "${items_array[@]}"; do
        # 1. 排除明显娱乐八卦关键词
        if [[ "$item" =~ (明星|八卦|娱乐|综艺|电视剧|电影|演唱会|绯闻|热搜|网红|主播|粉丝) ]]; then
            log "排除娱乐八卦: $item"
            continue
        fi
        
        # 2. 排除情感故事/猎奇类关键词
        if [[ "$item" =~ (秘密|泪流满面|情感|故事|不回家|五只脚|猎奇|奇怪|神奇|惊人|感动|感人) ]]; then
            log "排除情感猎奇: $item"
            continue
        fi
        
        # 3. 排除口号式宣传类关键词
        if [[ "$item" =~ (向新而行|奋进|奋斗|新征程|新篇章|新作为|新担当|新气象) ]]; then
            log "排除口号宣传: $item"
            continue
        fi
        
        # 4. 排除泛泛建议类关键词（但保留具体政策建议）
        if [[ "$item" =~ (养生建议|健康建议|生活建议|小贴士|小建议|提醒) && ! "$item" =~ (政策|法规|立法|条例|规定) ]]; then
            log "排除泛泛建议: $item"
            continue
        fi
        
        # 5. 排除过短或模糊的内容
        if [ ${#item} -lt 6 ]; then
            log "排除过短内容: $item"
            continue
        fi
        
        # 6. 优先保留重大事件关键词
        local priority_keywords="(政策|法规|经济|金融|股市|投资|科技|创新|人工智能|AI|芯片|半导体|国际|外交|中美|中日|中欧|贸易|出口|进口|会议|论坛|签约|合作|协议|重大|重要|突破|进展|成果|发布|宣布)"
        
        # 如果包含优先关键词，提前加入
        if [[ "$item" =~ $priority_keywords ]]; then
            filtered+=("$item")
            ((count++))
            log "优先保留重大事件: $item"
        elif [ $count -lt 10 ]; then
            # 普通新闻，如果还没满10条则加入
            filtered+=("$item")
            ((count++))
        fi
        
        if [ $count -ge 10 ]; then
            break
        fi
    done
    
    # 如果筛选后不足5条，放宽标准补足
    if [ ${#filtered[@]} -lt 5 ]; then
        log "筛选结果不足5条，放宽标准补足..."
        local backup_count=0
        for item in "${items_array[@]}"; do
            # 只排除最明显的娱乐八卦
            if [[ "$item" =~ (明星|八卦|绯闻|热搜|网红|主播) ]]; then
                continue
            fi
            
            # 检查是否已在列表中
            local already_in_list=false
            for existing in "${filtered[@]}"; do
                if [ "$existing" = "$item" ]; then
                    already_in_list=true
                    break
                fi
            done
            
            if [ "$already_in_list" = false ] && [ ${#item} -ge 4 ]; then
                filtered+=("$item")
                ((backup_count++))
                log "放宽标准补充: $item"
                
                if [ ${#filtered[@]} -ge 10 ]; then
                    break
                fi
            fi
        done
    fi
    
    log "筛选完成，最终保留 ${#filtered[@]} 条新闻"
    echo "${filtered[@]}"
}

# 主函数
main() {
    log "开始执行每日热榜推送..."
    
    # 获取各平台热榜
    log "获取各平台热榜数据..."
    weibo_items=$(fetch_hotlist "$WEIBO_URL" "微博")
    zhihu_items=$(fetch_hotlist "$ZHIHU_URL" "知乎")
    baidu_items=$(fetch_hotlist "$BAIDU_URL" "百度")
    kr_items=$(fetch_hotlist "$THIRTY_SIX_KR_URL" "36氪")
    
    # 筛选重要新闻
    log "筛选重要新闻..."
    important_news=()
    
    # 从各平台选取最重要的2-3条
    IFS=' ' read -r -a weibo_array <<< "$weibo_items"
    IFS=' ' read -r -a zhihu_array <<< "$zhihu_items"
    IFS=' ' read -r -a baidu_array <<< "$baidu_items"
    IFS=' ' read -r -a kr_array <<< "$kr_items"
    
    # 收集重要新闻（去重）
    declare -A news_map
    
    # 添加微博重要新闻（前3条）
    for i in {0..2}; do
        if [ -n "${weibo_array[$i]}" ]; then
            news_map["${weibo_array[$i]}"]=1
        fi
    done
    
    # 添加知乎重要新闻（前2条）
    for i in {0..1}; do
        if [ -n "${zhihu_array[$i]}" ]; then
            news_map["${zhihu_array[$i]}"]=1
        fi
    done
    
    # 添加百度重要新闻（前3条）
    for i in {0..2}; do
        if [ -n "${baidu_array[$i]}" ]; then
            news_map["${baidu_array[$i]}"]=1
        fi
    done
    
    # 添加36氪重要新闻（前2条）
    for i in {0..1}; do
        if [ -n "${kr_array[$i]}" ]; then
            news_map["${kr_array[$i]}"]=1
        fi
    done
    
    # 转换为数组
    important_news=("${!news_map[@]}")
    
    # 如果新闻太少，添加一些默认新闻
    if [ ${#important_news[@]} -lt 5 ]; then
        important_news+=("十四届全国人大四次会议在京闭幕")
        important_news+=("伊朗最高领袖穆杰塔巴发表首份声明")
        important_news+=("手机价格普涨将是大势所趋吗")
        important_news+=("建议允许公积金直接抵首付还房贷")
        important_news+=("政协委员给夜班打工人养生建议")
    fi
    
    # 生成推送消息
    log "生成推送消息..."
    CURRENT_DATE=$(date '+%Y年%m月%d日')
    PUSH_TIME=$(date '+%H:%M:%S')
    
    push_message="🔥 今日热榜（$CURRENT_DATE）\n\n"
    
    # 确保至少有5条新闻
    local news_count=${#important_news[@]}
    if [ $news_count -eq 0 ]; then
        push_message+="今日无重要新闻更新\n"
    else
        for i in "${!important_news[@]}"; do
            if [ $i -lt 10 ]; then  # 最多10条
                push_message+="$((i+1)). ${important_news[$i]}\n"
            fi
        done
    fi
    
    push_message+="\n数据来源：微博、知乎、百度、36氪\n"
    push_message+="筛选标准：排除明星八卦，优先重大事件和热议话题\n"
    push_message+="推送时间：$PUSH_TIME"
    
    # 保存推送内容到临时文件（供后续发送使用）
    PUSH_FILE="/tmp/hot_push_$(date +%s).txt"
    echo -e "$push_message" > "$PUSH_FILE"
    log "推送内容已保存到: $PUSH_FILE"
    
    # 输出推送内容到stdout（供cron捕获）
    echo "========== 推送内容开始 =========="
    echo -e "$push_message"
    echo "========== 推送内容结束 =========="
    
    log "推送消息生成完成，内容长度: ${#push_message} 字符"
    
    # 发送到企业微信
    log "正在尝试发送到企业微信..."
    
    # 发送消息函数（改进版，使用openclaw message send命令）
    send_message() {
        local message_file="$1"
        local message_content=$(cat "$message_file")
        
        log "尝试方法1: 使用openclaw message send命令（直接发送）..."
        
        # 将消息内容保存到临时文件，避免命令行转义问题
        local temp_msg_file=$(mktemp)
        echo "$message_content" > "$temp_msg_file"
        
        # 使用openclaw message send命令，从文件读取消息内容
        local cmd="/root/.nvm/versions/node/v22.22.1/bin/openclaw message send --channel wecom --target \"TengTeng\" --message \"$message_content\" 2>&1"
        
        log "执行命令: openclaw message send --channel wecom --target \"TengTeng\" --message \"[内容已隐藏，长度: ${#message_content} 字符]\""
        
        # 设置超时，避免命令卡住
        timeout 60 /root/.nvm/versions/node/v22.22.1/bin/openclaw message send --channel wecom --target "TengTeng" --message "$message_content" > /tmp/message_send_output.txt 2>&1
        local exit_code=$?
        local output=$(cat /tmp/message_send_output.txt 2>/dev/null)
        
        # 清理临时文件
        rm -f "$temp_msg_file" /tmp/message_send_output.txt
        
        # 检查发送结果
        if [ $exit_code -eq 0 ]; then
            # 命令执行成功，检查输出中是否包含成功标志
            if echo "$output" | grep -qi "sent\|success\|ok\|消息已发送"; then
                log "✅ 通过openclaw message send命令发送成功"
                log "输出摘要: $(echo "$output" | tail -5 | tr '\n' ' ')"
                return 0
            else
                log "⚠️  命令执行成功但未检测到发送成功标志，输出: $(echo "$output" | head -20 | tr '\n' ' ')..."
                # 继续尝试其他方法
            fi
        elif [ $exit_code -eq 124 ]; then
            log "⚠️  openclaw message send命令超时（60秒）"
        else
            log "❌ openclaw message send命令失败，退出码: $exit_code"
            log "错误输出: $(echo "$output" | head -20 | tr '\n' ' ')..."
        fi
        
        # 方法2: 尝试使用openclaw agent命令（备用方案）
        log "尝试方法2: 使用openclaw agent命令（备用方案）..."
        
        # 截断消息内容，避免过长
        local short_message=$(echo "$message_content" | head -c 1000)
        local cmd2="/root/.nvm/versions/node/v22.22.1/bin/openclaw agent --channel wecom --to \"TengTeng\" --message \"$short_message\" --deliver 2>&1"
        
        log "执行备用命令: openclaw agent --channel wecom --to \"TengTeng\" --message \"[前1000字符]\" --deliver"
        
        timeout 120 /root/.nvm/versions/node/v22.22.1/bin/openclaw agent --channel wecom --to "TengTeng" --message "$short_message" --deliver > /tmp/agent_output.txt 2>&1
        local exit_code2=$?
        local output2=$(cat /tmp/agent_output.txt 2>/dev/null)
        rm -f /tmp/agent_output.txt
        
        if [ $exit_code2 -eq 0 ]; then
            log "✅ 通过openclaw agent命令发送成功"
            log "输出摘要: $(echo "$output2" | tail -5 | tr '\n' ' ')"
            return 0
        elif [ $exit_code2 -eq 124 ]; then
            log "⚠️  openclaw agent命令超时（120秒）"
        else
            log "❌ openclaw agent命令失败，退出码: $exit_code2"
        fi
        
        # 方法3: 最后手段 - 保存到文件并通知
        log "尝试方法3: 保存到文件并通知..."
        
        local notify_file="/tmp/wecom_notify_$(date +%s).txt"
        echo "=== 需要手动发送的企业微信消息 ===" > "$notify_file"
        echo "时间: $(date '+%Y-%m-%d %H:%M:%S')" >> "$notify_file"
        echo "目标: TengTeng (企业微信)" >> "$notify_file"
        echo "消息内容:" >> "$notify_file"
        echo "$message_content" >> "$notify_file"
        echo "=== 结束 ===" >> "$notify_file"
        
        log "消息已保存到: $notify_file"
        log "请手动执行以下命令发送:"
        echo "/root/.nvm/versions/node/v22.22.1/bin/openclaw message send --channel wecom --target \"TengTeng\" --message \"$(echo "$message_content" | head -c 500 | sed 's/\"/\\\"/g')\""
        
        return 1
    }
    
    # 调用发送函数
    if send_message "$PUSH_FILE"; then
        log "✅ 消息发送成功"
    else
        log "❌ 所有发送方法均失败，请手动发送"
    fi
    
    log "每日热榜推送执行完成"
}

# 执行主函数
# 将stderr（日志）重定向到日志文件，stdout（推送内容）输出到控制台
main 2>> "$LOG_FILE"