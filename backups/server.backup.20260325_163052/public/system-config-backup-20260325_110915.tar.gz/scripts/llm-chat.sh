#!/bin/bash

# LLM Chat Script via Browser Automation
# Uses agent-browser to interact with LLM websites

set -e

# Default configuration
SESSION_NAME="llm_chat_$(date +%s)"
OUTPUT_FILE=""
MODEL=""
URL=""
QUESTION=""
HEADED=false
DEBUG=false
TIMEOUT=30000

# Known LLM websites
declare -A LLM_URLS=(
    ["wenxin"]="https://yiyan.baidu.com"
    ["tongyi"]="https://tongyi.aliyun.com"
    ["xinghuo"]="https://xinghuo.xfyun.cn"
    ["chatgpt"]="https://chat.openai.com"
    ["claude"]="https://claude.ai"
    ["gemini"]="https://gemini.google.com"
)

# Element selectors for each model (these may need to be updated as websites change)
declare -A INPUT_SELECTORS=(
    ["wenxin"]='[placeholder*="输入"] textarea, textarea[placeholder*="说点什么"], textarea'
    ["tongyi"]='textarea[placeholder*="输入"], textarea'
    ["xinghuo"]='textarea[placeholder*="输入"], textarea'
    ["chatgpt"]='#prompt-textarea, textarea[placeholder*="Message"]'
    ["claude"]='[contenteditable="true"], textarea'
    ["gemini"]='textarea, [contenteditable="true"]'
)

declare -A SUBMIT_SELECTORS=(
    ["wenxin"]='button:has-text("发送"), button:has-text("提问")'
    ["tongyi"]='button:has-text("发送"), button:has-text("提问")'
    ["xinghuo"]='button:has-text("发送"), button:has-text("提问")'
    ["chatgpt"]='button[data-testid*="send-button"]'
    ["claude"]='button:has-text("Send")'
    ["gemini"]='button[aria-label*="send"], button:has-text("发送")'
)

declare -A RESPONSE_SELECTORS=(
    ["wenxin"]='.answer-content, .response-content, [class*="answer"]'
    ["tongyi"]='.response-content, [class*="answer"]'
    ["xinghuo"]='.response-content, [class*="answer"]'
    ["chatgpt"]='[data-message-author-role="assistant"]'
    ["claude"]='[class*="message"]:has-text'
    ["gemini"]='[class*="message"], [data-message-author-role="assistant"]'
)

# Print usage
usage() {
    cat << EOF
Usage: $0 [OPTIONS]

Options:
  -m, --model MODEL       Predefined model: wenxin, tongyi, xinghuo, chatgpt, claude, gemini
  -u, --url URL           Custom LLM website URL
  -q, --question TEXT     Question to ask (required)
  -o, --output FILE       Save response to file
  -s, --session NAME      Browser session name (default: auto-generated)
  -t, --timeout MS        Timeout in milliseconds (default: 30000)
  -H, --headed            Show browser window for debugging
  -d, --debug             Enable debug output
  -h, --help              Show this help message

Examples:
  $0 -m wenxin -q "特斯拉二月份的销量数据是什么？"
  $0 -u "https://yiyan.baidu.com" -q "你好，请介绍一下人工智能"
  $0 -m chatgpt -q "What is the capital of France?" -o answer.txt

Note:
  - You need to be logged in to the LLM website in a previous session for this to work
  - The script uses agent-browser's session persistence
  - Element selectors may need updating if websites change their UI
EOF
}

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -m|--model)
            MODEL="$2"
            shift 2
            ;;
        -u|--url)
            URL="$2"
            shift 2
            ;;
        -q|--question)
            QUESTION="$2"
            shift 2
            ;;
        -o|--output)
            OUTPUT_FILE="$2"
            shift 2
            ;;
        -s|--session)
            SESSION_NAME="$2"
            shift 2
            ;;
        -t|--timeout)
            TIMEOUT="$2"
            shift 2
            ;;
        -H|--headed)
            HEADED=true
            shift
            ;;
        -d|--debug)
            DEBUG=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

# Debug function
debug() {
    if [ "$DEBUG" = true ]; then
        echo "[DEBUG] $1"
    fi
}

# Error function
error() {
    echo "[ERROR] $1" >&2
    exit 1
}

# Validate arguments
if [ -z "$QUESTION" ]; then
    error "Question is required. Use -q or --question"
fi

if [ -n "$MODEL" ]; then
    if [ -z "${LLM_URLS[$MODEL]}" ]; then
        error "Unknown model: $MODEL. Available models: ${!LLM_URLS[*]}"
    fi
    URL="${LLM_URLS[$MODEL]}"
elif [ -z "$URL" ]; then
    error "Either --model or --url must be specified"
fi

# Set agent-browser command with session
AGENT_BROWSER_CMD="agent-browser --session $SESSION_NAME"
if [ "$HEADED" = true ]; then
    AGENT_BROWSER_CMD="$AGENT_BROWSER_CMD --headed"
fi

# Function to get element ref using semantic locator
get_element_ref() {
    local selector_type="$1"
    local selector_value="$2"
    local max_attempts="${3:-3}"
    
    for attempt in $(seq 1 $max_attempts); do
        debug "Attempt $attempt to find element with $selector_type: $selector_value"
        
        # Try to find element
        local result
        if [ "$selector_type" = "role" ]; then
            result=$(eval "$AGENT_BROWSER_CMD find role $selector_value --json 2>/dev/null || true")
        elif [ "$selector_type" = "text" ]; then
            result=$(eval "$AGENT_BROWSER_CMD find text \"$selector_value\" --json 2>/dev/null || true")
        elif [ "$selector_type" = "css" ]; then
            result=$(eval "$AGENT_BROWSER_CMD snapshot -i --json 2>/dev/null | jq -r '.elements[] | select(.selector | contains(\"$selector_value\")) | .ref' | head -1 || true")
        fi
        
        if [ -n "$result" ] && [ "$result" != "null" ] && [ "$result" != "" ]; then
            echo "$result"
            return 0
        fi
        
        if [ $attempt -lt $max_attempts ]; then
            sleep 2
            eval "$AGENT_BROWSER_CMD wait 2000" > /dev/null 2>&1 || true
        fi
    done
    
    echo ""
    return 1
}

# Main function
main() {
    echo "Starting LLM chat session: $SESSION_NAME"
    echo "URL: $URL"
    echo "Question: $QUESTION"
    
    # Step 1: Open the URL
    debug "Opening URL: $URL"
    if ! eval "$AGENT_BROWSER_CMD open \"$URL\" --timeout $TIMEOUT" > /dev/null 2>&1; then
        error "Failed to open URL: $URL"
    fi
    
    # Wait for page to load
    debug "Waiting for page to load"
    eval "$AGENT_BROWSER_CMD wait --load networkidle --timeout $TIMEOUT" > /dev/null 2>&1 || true
    sleep 3
    
    # Step 2: Take snapshot to see available elements
    debug "Taking snapshot of page"
    if [ "$DEBUG" = true ]; then
        eval "$AGENT_BROWSER_CMD snapshot -i" 2>&1 | head -50
    fi
    
    # Step 3: Find input field
    echo "Looking for input field..."
    
    local input_ref=""
    if [ -n "$MODEL" ] && [ -n "${INPUT_SELECTORS[$MODEL]}" ]; then
        # Try model-specific selector
        input_ref=$(get_element_ref "css" "${INPUT_SELECTORS[$MODEL]}")
    fi
    
    if [ -z "$input_ref" ]; then
        # Try general textarea or contenteditable
        input_ref=$(get_element_ref "css" "textarea, [contenteditable=\"true\"]")
    fi
    
    if [ -z "$input_ref" ]; then
        error "Could not find input field on the page"
    fi
    
    debug "Found input field: $input_ref"
    
    # Step 4: Type the question
    echo "Typing question..."
    if ! eval "$AGENT_BROWSER_CMD fill $input_ref \"$QUESTION\" --timeout $TIMEOUT" > /dev/null 2>&1; then
        error "Failed to type question"
    fi
    
    sleep 1
    
    # Step 5: Find and click submit button
    echo "Looking for submit button..."
    
    local submit_ref=""
    if [ -n "$MODEL" ] && [ -n "${SUBMIT_SELECTORS[$MODEL]}" ]; then
        # Try model-specific selector
        submit_ref=$(get_element_ref "css" "${SUBMIT_SELECTORS[$MODEL]}")
    fi
    
    if [ -z "$submit_ref" ]; then
        # Try general button with send/submit text
        submit_ref=$(get_element_ref "text" "发送") || \
        submit_ref=$(get_element_ref "text" "Send") || \
        submit_ref=$(get_element_ref "text" "提问") || \
        submit_ref=$(get_element_ref "text" "Submit")
    fi
    
    if [ -z "$submit_ref" ]; then
        # Try any button
        submit_ref=$(get_element_ref "role" "button")
    fi
    
    if [ -z "$submit_ref" ]; then
        error "Could not find submit button"
    fi
    
    debug "Found submit button: $submit_ref"
    
    # Step 6: Click submit
    echo "Submitting question..."
    if ! eval "$AGENT_BROWSER_CMD click $submit_ref --timeout $TIMEOUT" > /dev/null 2>&1; then
        error "Failed to click submit button"
    fi
    
    # Step 7: Wait for response
    echo "Waiting for response (this may take a while)..."
    
    # Wait for network to be idle after submission
    eval "$AGENT_BROWSER_CMD wait --load networkidle --timeout 60000" > /dev/null 2>&1 || true
    
    # Additional wait for response generation
    sleep 10
    
    # Step 8: Get response
    echo "Extracting response..."
    
    local response_text=""
    local max_response_attempts=5
    
    for attempt in $(seq 1 $max_response_attempts); do
        debug "Attempt $attempt to extract response"
        
        # Try to find response elements
        local response_ref=""
        if [ -n "$MODEL" ] && [ -n "${RESPONSE_SELECTORS[$MODEL]}" ]; then
            response_ref=$(get_element_ref "css" "${RESPONSE_SELECTORS[$MODEL]}")
        fi
        
        if [ -z "$response_ref" ]; then
            # Try to find any new content that appeared after submission
            eval "$AGENT_BROWSER_CMD snapshot -i --json" > /tmp/snapshot.json 2>/dev/null || true
            response_ref=$(jq -r '.elements[] | select(.text | length > 50) | .ref' /tmp/snapshot.json 2>/dev/null | head -1 || true)
        fi
        
        if [ -n "$response_ref" ]; then
            debug "Found response element: $response_ref"
            response_text=$(eval "$AGENT_BROWSER_CMD get text $response_ref --timeout $TIMEOUT" 2>/dev/null || true)
            
            if [ -n "$response_text" ] && [ ${#response_text} -gt 20 ]; then
                break
            fi
        fi
        
        if [ $attempt -lt $max_response_attempts ]; then
            sleep 5
            debug "Waiting for response to generate..."
        fi
    done
    
    if [ -z "$response_text" ] || [ ${#response_text} -lt 20 ]; then
        echo "Warning: Could not extract full response. Trying alternative method..."
        
        # Try to get all text from the page
        response_text=$(eval "$AGENT_BROWSER_CMD eval \"document.body.innerText\" --timeout $TIMEOUT" 2>/dev/null || true)
        
        # Filter to likely response content (text after question)
        # This is a simple heuristic and may need improvement
        local temp_file=$(mktemp)
        echo "$response_text" > "$temp_file"
        response_text=$(tail -n 50 "$temp_file" | head -n 40)
        rm "$temp_file"
    fi
    
    # Step 9: Output response
    echo ""
    echo "="*60
    echo "RESPONSE:"
    echo "="*60
    echo "$response_text"
    echo "="*60
    
    # Save to file if requested
    if [ -n "$OUTPUT_FILE" ]; then
        echo "$response_text" > "$OUTPUT_FILE"
        echo "Response saved to: $OUTPUT_FILE"
    fi
    
    # Step 10: Close browser session
    debug "Closing browser session"
    eval "$AGENT_BROWSER_CMD close" > /dev/null 2>&1 || true
    
    echo "Done!"
}

# Check dependencies
if ! command -v agent-browser &> /dev/null; then
    error "agent-browser is not installed. Please install it first: npm install -g agent-browser"
fi

if ! command -v jq &> /dev/null; then
    echo "Warning: jq is not installed. Some features may not work properly."
    echo "Install with: apt-get install jq  # or your package manager"
fi

# Run main function
main