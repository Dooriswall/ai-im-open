#!/bin/bash

# 定时推送任务监控脚本
# 每小时运行一次，检查定时推送任务状态

set -e

# 配置
LOG_FILE="/tmp/daily-push-monitor.log"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
WE_CHAT_USER="TengTeng"

# 日志函数
log() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] $1" | tee -a "$LOG_FILE" >&2
}

# 检查函数
check_cron_job() {
    log "检查cron定时任务..."
    
    # 检查cron服务状态
    if ! systemctl is-active --quiet cron 2>/dev/null; then
        log "❌ cron服务未运行"
        return 1
    fi
    
    # 检查定时任务配置 - 更新为检查新脚本名称
    if ! crontab -l 2>/dev/null | grep -q "simple-news-push.sh"; then
        log "❌ 未找到定时推送cron任务（simple-news-push.sh）"
        return 1
    fi
    
    # 检查具体任务
    local cron_count=$(crontab -l 2>/dev/null | grep -c "simple-news-push.sh")
    log "✅ 找到 $cron_count 个定时推送cron任务"
    
    # 显示任务详情
    crontab -l 2>/dev/null | grep "simple-news-push.sh" | while read line; do
        log "  任务: $line"
    done
    
    return 0
}

check_push_script() {
    log "检查推送脚本..."
    
    local script_path="/root/.openclaw/workspace/scripts/simple-news-push.sh"
    
    # 检查脚本是否存在
    if [ ! -f "$script_path" ]; then
        log "❌ 推送脚本不存在: $script_path"
        return 1
    fi
    
    # 检查脚本权限
    if [ ! -x "$script_path" ]; then
        log "⚠️  脚本不可执行，尝试修复权限..."
        chmod +x "$script_path"
    fi
    
    # 检查脚本内容
    local line_count=$(wc -l < "$script_path")
    log "✅ 推送脚本存在，行数: $line_count，权限: $(ls -la "$script_path" | awk '{print $1}')"
    
    return 0
}

check_openclaw_service() {
    log "检查OpenClaw服务..."
    
    # 检查Gateway服务状态
    if ! XDG_RUNTIME_DIR=/run/user/0 systemctl --user is-active --quiet openclaw-gateway 2>/dev/null; then
        log "❌ OpenClaw Gateway服务未运行"
        return 1
    fi
    
    # 获取Gateway PID
    local gateway_pid=$(XDG_RUNTIME_DIR=/run/user/0 systemctl --user show --property=MainPID --value openclaw-gateway 2>/dev/null)
    if [ -z "$gateway_pid" ] || [ "$gateway_pid" -eq 0 ]; then
        log "❌ 无法获取Gateway PID"
        return 1
    fi
    
    log "✅ OpenClaw Gateway服务运行中，PID: $gateway_pid"
    
    # 检查端口
    if netstat -tln 2>/dev/null | grep -q ":18789"; then
        log "✅ Gateway端口 18789 监听中"
    else
        log "⚠️  Gateway端口 18789 未监听"
    fi
    
    return 0
}

check_recent_execution() {
    log "检查最近执行情况..."
    
    local push_log="/tmp/simple-news-push.log"
    
    if [ ! -f "$push_log" ]; then
        log "⚠️  推送日志文件不存在: $push_log"
        return 1
    fi
    
    # 检查最近24小时内的执行记录
    local recent_count=$(grep -c "开始执行每日热榜推送" "$push_log" 2>/dev/null || echo 0)
    log "推送日志总执行次数: $recent_count"
    
    if [ "$recent_count" -eq 0 ]; then
        log "⚠️  未找到执行记录，定时任务可能从未成功运行"
        return 1
    fi
    
    # 获取最后一次执行时间
    local last_exec=$(grep "开始执行每日热榜推送" "$push_log" | tail -1 | sed 's/.*\[\(.*\)\].*/\1/' 2>/dev/null || echo "未知")
    log "最后一次执行时间: $last_exec"
    
    # 检查是否有错误
    local error_count=$(grep -c "ERROR\|失败" "$push_log" 2>/dev/null || echo 0)
    if [ "$error_count" -gt 0 ]; then
        log "⚠️  推送日志中发现 $error_count 个错误"
        grep "ERROR\|失败" "$push_log" | tail -3 | while read error; do
            log "  错误示例: $error"
        done
    else
        log "✅ 推送日志中未发现错误"
    fi
    
    return 0
}

test_message_send() {
    log "测试消息发送功能..."
    
    # 尝试使用OpenClaw CLI发送测试消息
    local test_message="[监控测试] 定时推送任务监控运行正常，时间: $TIMESTAMP"
    
    log "尝试发送测试消息: $test_message"
    
    # 方法1: 使用openclaw agent命令
    local cmd="openclaw agent --channel wecom --to \"$WE_CHAT_USER\" --message \"$test_message\" --deliver 2>&1"
    log "执行命令: $cmd"
    
    local output=$(eval "$cmd" 2>&1)
    local exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        log "✅ 测试消息发送成功"
        log "输出: $output"
        return 0
    else
        log "❌ 测试消息发送失败，退出码: $exit_code"
        log "错误输出: $output"
        
        # 方法2: 尝试其他发送方式
        log "尝试备选发送方法..."
        
        # 检查是否有其他可用的OpenClaw CLI
        local openclaw_path=$(which openclaw 2>/dev/null)
        if [ -n "$openclaw_path" ]; then
            log "找到OpenClaw CLI: $openclaw_path"
        fi
        
        return 1
    fi
}

check_cron_execution_time() {
    log "检查cron执行时间..."
    
    local current_hour=$(date '+%H')
    local current_minute=$(date '+%M')
    
    log "当前时间: ${current_hour}:${current_minute}"
    
    # 检查下一个预定执行时间
    local next_morning=""
    local next_evening=""
    
    if [ "$current_hour" -lt 9 ]; then
        next_morning="今天 09:00"
    elif [ "$current_hour" -eq 9 ] && [ "$current_minute" -lt 59 ]; then
        next_morning="今天 09:00 (已过)"
    else
        next_morning="明天 09:00"
    fi
    
    if [ "$current_hour" -lt 21 ]; then
        next_evening="今天 21:00"
    elif [ "$current_hour" -eq 21 ] && [ "$current_minute" -lt 59 ]; then
        next_evening="今天 21:00 (已过)"
    else
        next_evening="明天 21:00"
    fi
    
    log "下次推送时间: 早上 $next_morning, 晚上 $next_evening"
    
    # 如果是测试时间（11:05），提醒测试任务
    if [ "$current_hour" -eq 11 ] && [ "$current_minute" -ge 5 ] && [ "$current_minute" -lt 10 ]; then
        log "⚠️  现在是测试任务执行时间 (11:05)"
    fi
}

send_status_report() {
    log "发送状态报告..."
    
    # 收集状态信息
    local status_report="🕒 定时推送任务监控报告\n"
    status_report+="时间: $TIMESTAMP\n\n"
    
    # 检查结果汇总
    status_report+="📊 检查结果:\n"
    
    # 执行检查并收集结果
    local all_checks_passed=true
    
    if check_cron_job; then
        status_report+="✅ cron定时任务: 正常\n"
    else
        status_report+="❌ cron定时任务: 异常\n"
        all_checks_passed=false
    fi
    
    if check_push_script; then
        status_report+="✅ 推送脚本: 正常\n"
    else
        status_report+="❌ 推送脚本: 异常\n"
        all_checks_passed=false
    fi
    
    if check_openclaw_service; then
        status_report+="✅ OpenClaw服务: 正常\n"
    else
        status_report+="❌ OpenClaw服务: 异常\n"
        all_checks_passed=false
    fi
    
    # 尝试发送测试消息
    if test_message_send; then
        status_report+="✅ 消息发送测试: 成功\n"
    else
        status_report+="❌ 消息发送测试: 失败\n"
        all_checks_passed=false
    fi
    
    check_cron_execution_time
    
    # 总体状态
    if [ "$all_checks_passed" = true ]; then
        status_report+="\n🎉 所有检查通过，定时推送任务状态良好！\n"
    else
        status_report+="\n⚠️  部分检查未通过，请检查定时推送任务配置。\n"
    fi
    
    # 输出到日志
    log "监控报告生成完成"
    echo -e "$status_report" >> "$LOG_FILE"
    
    # 如果测试消息发送失败，不重复发送报告（避免循环）
    # 仅在手动触发或调试时发送报告
    if [ "${SEND_REPORT:-false}" = "true" ]; then
        log "发送监控报告到企业微信..."
        # 这里可以添加发送报告的代码
    fi
}

# 主函数
main() {
    log "========================================"
    log "开始定时推送任务监控检查"
    log "========================================"
    
    # 执行所有检查
    send_status_report
    
    log "========================================"
    log "监控检查完成"
    log "========================================"
    
    # 返回总体状态
    return 0
}

# 执行主函数
main 2>&1 | tee -a "$LOG_FILE"