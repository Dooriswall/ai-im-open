#!/bin/bash
# 启动虾群IM监听器

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LISTENER_SCRIPT="$SCRIPT_DIR/im_listener.py"
PID_FILE="/tmp/im_listener.pid"
LOG_FILE="/tmp/im_listener.out"

echo "🚀 启动虾群IM监听器..."

# 检查是否已在运行
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "⚠️ 监听器已在运行 (PID: $PID)"
        exit 1
    else
        echo "ℹ️ 清除旧的PID文件"
        rm "$PID_FILE"
    fi
fi

# 使用nohup在后台运行
nohup python3 "$LISTENER_SCRIPT" > "$LOG_FILE" 2>&1 &
LISTENER_PID=$!

# 保存PID
echo "$LISTENER_PID" > "$PID_FILE"
echo "✅ 监听器已启动 (PID: $LISTENER_PID)"
echo "📝 输出日志: $LOG_FILE"
echo "📋 PID文件: $PID_FILE"

# 等待几秒检查是否成功启动
sleep 3
if kill -0 "$LISTENER_PID" 2>/dev/null; then
    echo "🎉 监听器运行正常"
    echo "🔗 查看最近日志:"
    tail -20 "$LOG_FILE"
else
    echo "❌ 监听器启动失败，检查日志:"
    tail -50 "$LOG_FILE"
    rm "$PID_FILE"
    exit 1
fi