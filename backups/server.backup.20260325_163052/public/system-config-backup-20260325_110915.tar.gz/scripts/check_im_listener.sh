#!/bin/bash
# 检查虾群IM监听器状态

PID_FILE="/tmp/im_listener.pid"
LOG_FILE="/tmp/im_listener.out"
MESSAGES_LOG="/tmp/im_messages.log"
MENTIONS_LOG="/tmp/mentions.log"

echo "📊 虾群IM监听器状态检查"

# 检查进程
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "✅ 监听器正在运行 (PID: $PID)"
        
        # 检查运行时间
        if command -v ps >/dev/null 2>&1; then
            RUN_TIME=$(ps -o etime= -p "$PID" 2>/dev/null || echo "未知")
            echo "⏱️  运行时间: $RUN_TIME"
        fi
    else
        echo "❌ PID文件存在但进程未运行 (PID: $PID)"
    fi
else
    echo "ℹ️ 监听器未运行 (无PID文件)"
fi

echo ""
echo "📈 日志统计:"

# 检查消息日志
if [ -f "$MESSAGES_LOG" ]; then
    MSG_COUNT=$(wc -l < "$MESSAGES_LOG")
    echo "💬 总消息数: $MSG_COUNT"
    
    if [ "$MSG_COUNT" -gt 0 ]; then
        LAST_MSG=$(tail -1 "$MESSAGES_LOG")
        LAST_TIME=$(echo "$LAST_MSG" | cut -d' ' -f1-2)
        echo "🕒 最后消息: $LAST_TIME"
        
        # 显示最近3条消息
        echo "📋 最近消息:"
        tail -3 "$MESSAGES_LOG" | while read line; do
            echo "   $line"
        done
    fi
else
    echo "ℹ️ 消息日志文件不存在"
fi

echo ""
# 检查被提及日志
if [ -f "$MENTIONS_LOG" ]; then
    MENTION_COUNT=$(wc -l < "$MENTIONS_LOG")
    echo "🔔 被提及次数: $MENTION_COUNT"
    
    if [ "$MENTION_COUNT" -gt 0 ]; then
        echo "📋 最近提及:"
        tail -3 "$MENTIONS_LOG" | while read line; do
            TIME=$(echo "$line" | cut -d':' -f1)
            CONTENT=$(echo "$line" | cut -d':' -f2-)
            HUMAN_TIME=$(date -d "@$TIME" "+%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "$TIME")
            echo "   $HUMAN_TIME: $CONTENT"
        done
    fi
else
    echo "ℹ️ 提及日志文件不存在"
fi

echo ""
# 检查输出日志
if [ -f "$LOG_FILE" ]; then
    LOG_SIZE=$(du -h "$LOG_FILE" | cut -f1)
    echo "📝 输出日志大小: $LOG_SIZE"
    
    # 检查是否有错误
    ERROR_COUNT=$(grep -c "❌\|Error\|error\|失败\|Failed" "$LOG_FILE" 2>/dev/null || echo 0)
    if [ "$ERROR_COUNT" -gt 0 ]; then
        echo "⚠️  发现 $ERROR_COUNT 个错误/警告"
    fi
fi

echo ""
echo "🔗 WebSocket连接状态:"
if curl -s http://81.70.39.176:8800/api/health >/dev/null 2>&1; then
    echo "✅ IM服务器可访问"
else
    echo "❌ IM服务器无法访问"
fi