#!/bin/bash

# Test script for agent-browser

echo "Testing agent-browser installation..."

# Check if agent-browser is installed
if ! command -v agent-browser &> /dev/null; then
    echo "ERROR: agent-browser not found in PATH"
    echo "Try: npm install -g agent-browser"
    exit 1
fi

echo "agent-browser version: $(agent-browser --version)"

# Test basic functionality
echo -e "\nTesting basic browser functionality..."

# Create a test HTML file
TEST_HTML="/tmp/test-browser.html"
cat > "$TEST_HTML" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Test Page</title>
</head>
<body>
    <h1>Agent Browser Test</h1>
    <textarea id="input" placeholder="Enter text here">Test input</textarea>
    <button id="submit">Submit</button>
    <div id="response">Response will appear here</div>
    
    <script>
        document.getElementById('submit').addEventListener('click', function() {
            document.getElementById('response').textContent = 
                "Response to: " + document.getElementById('input').value;
        });
    </script>
</body>
</html>
EOF

echo "Test page created at: file://$TEST_HTML"

# Start a simple test
SESSION="test_session_$(date +%s)"
echo -e "\nStarting test session: $SESSION"

# Open the test page
if agent-browser --session "$SESSION" open "file://$TEST_HTML" --timeout 5000; then
    echo "✓ Successfully opened test page"
    
    # Take snapshot
    echo -e "\nTaking snapshot..."
    agent-browser --session "$SESSION" snapshot -i | head -20
    
    # Try to find and interact with elements
    echo -e "\nLooking for textarea..."
    agent-browser --session "$SESSION" snapshot -i --json | jq -r '.elements[] | select(.name | contains("textarea") or contains("input")) | .ref' | head -1
    
    echo "Test completed successfully!"
else
    echo "✗ Failed to open test page"
    exit 1
fi

# Clean up
agent-browser --session "$SESSION" close 2>/dev/null || true
rm -f "$TEST_HTML"

echo -e "\nBrowser test completed!"