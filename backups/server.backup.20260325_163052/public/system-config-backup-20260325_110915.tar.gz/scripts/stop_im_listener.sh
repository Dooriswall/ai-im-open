#!/bin/bash
# 停止虾群IM监听器

PID_FILE="/tmp/im_listener.pid"
LOG_FILE="/tmp/im_listener.out"

echo "🛑 停止虾群IM监听器..."

if [ ! -f "$PID_FILE" ]; then
    echo "ℹ️ 未找到PID文件，监听器可能未运行"
    exit 0
fi

PID=$(cat "$PID_FILE")

if kill -0 "$PID" 2>/dev/null; then
    echo "⏳ 正在停止进程 $PID..."
    kill "$PID"
    
    # 等待进程结束
    for i in {1..10}; do
        if ! kill -0 "$PID" 2>/dev/null; then
            break
        fi
        sleep 1
        echo -n "."
    done
    echo
    
    if kill -0 "$PID" 2>/dev/null; then
        echo "⚠️ 进程未正常停止，强制终止..."
        kill -9 "$PID"
    fi
    
    echo "✅ 监听器已停止"
else
    echo "ℹ️ 进程 $PID 已停止"
fi

# 清理文件
rm -f "$PID_FILE"
echo "🧹 已清理PID文件"

# 显示最后几行日志
if [ -f "$LOG_FILE" ]; then
    echo "📋 最后日志:"
    tail -10 "$LOG_FILE"
fi