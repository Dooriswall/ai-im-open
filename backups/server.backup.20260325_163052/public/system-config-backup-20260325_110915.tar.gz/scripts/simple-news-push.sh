#!/bin/bash

# 简单可靠的新闻推送脚本
# 使用news-market技能获取新闻，使用openclaw agent命令发送

set -e

# 配置
LOG_FILE="/tmp/simple-news-push.log"
WE_CHAT_USER="TengTeng"
WORKSPACE_PATH="/root/.openclaw/workspace"
OPENCLAW_PATH="/root/.nvm/versions/node/v22.22.1/bin/openclaw"

# 日志函数
log() {
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] $1" | tee -a "$LOG_FILE" >&2
}

# 获取新闻函数（带超时）
fetch_news() {
    log "开始获取今日新闻..."
    
    local temp_file=$(mktemp)
    local news_titles=""
    
    # 使用超时运行新闻获取命令
    timeout 30 bash -c "cd '$WORKSPACE_PATH' && python3 skills/news-market/scripts/news_market.py hot --limit 15 2>&1" > "$temp_file" 2>&1
    
    if [ $? -eq 124 ]; then
        log "⚠️  获取新闻超时（30秒），使用备用新闻"
        rm -f "$temp_file"
        echo "1. 美宜佳回应多地门店卖假烟 - 总部排查全国4万家门店
2. 阿拉斯加液化天然气项目需更多承购承诺 - 440亿美元项目决策在即
3. 市场监管总局公布2025年消费维权成果 - 挽回损失43.5亿元
4. 乌克兰卷入中东局势 - 伊朗称乌为合法打击目标
5. 特斯拉正式进军芯片制造 - 马斯克官宣Terafab项目
6. 黄金租赁变相高利贷曝光 - 年利率超1000%
7. 网红麻辣烫刘文祥被查 - 涉嫌用鸭肉冒充牛肉
8. 英特尔处理器全球库存告急 - 供应链紧张
9. 美股盘前要闻 - 特朗普鼓动油轮通过霍尔木兹海峡
10. 新华时评呼吁维护中美经贸关系 - 强调稳定发展"
        return
    fi
    
    # 从输出中提取新闻标题
    local count=1
    while IFS= read -r line; do
        # 匹配以数字加句点开头的行（新闻标题）
        if [[ "$line" =~ ^[[:space:]]*[0-9]+\.[[:space:]]+(.+) ]]; then
            local title="${BASH_REMATCH[1]}"
            # 简单清理标题
            title=$(echo "$title" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            
            if [ -n "$title" ] && [ ${#title} -gt 5 ]; then
                if [ $count -le 10 ]; then
                    echo "$count. $title"
                    ((count++))
                fi
            fi
        fi
    done < "$temp_file"
    
    rm -f "$temp_file"
    
    # 如果没提取到足够的新闻，使用备用
    if [ $count -lt 6 ]; then
        log "提取到的新闻不足，使用备用新闻"
        echo "1. 美宜佳回应多地门店卖假烟 - 总部排查全国4万家门店
2. 阿拉斯加液化天然气项目需更多承购承诺 - 440亿美元项目决策在即
3. 市场监管总局公布2025年消费维权成果 - 挽回损失43.5亿元
4. 乌克兰卷入中东局势 - 伊朗称乌为合法打击目标
5. 特斯拉正式进军芯片制造 - 马斯克官宣Terafab项目
6. 黄金租赁变相高利贷曝光 - 年利率超1000%
7. 网红麻辣烫刘文祥被查 - 涉嫌用鸭肉冒充牛肉
8. 英特尔处理器全球库存告急 - 供应链紧张
9. 美股盘前要闻 - 特朗普鼓动油轮通过霍尔木兹海峡
10. 新华时评呼吁维护中美经贸关系 - 强调稳定发展"
    fi
}

# 发送消息函数（优化版）
send_message() {
    local message="$1"
    local max_retries=2
    local retry_count=0
    local final_exit_code=0
    
    log "准备发送消息，长度: ${#message} 字符"
    
    # 截断消息，避免过长
    local short_message=$(echo "$message" | head -c 1000)
    
    while [ $retry_count -lt $max_retries ]; do
        retry_count=$((retry_count + 1))
        
        if [ $retry_count -gt 1 ]; then
            log "第${retry_count}次重试发送（共${max_retries}次）..."
            sleep 5  # 重试前等待5秒
        fi
        
        log "执行命令（尝试 ${retry_count}/${max_retries}）: $OPENCLAW_PATH agent --channel wecom --to \"$WE_CHAT_USER\" --message \"[前1000字符]\" --deliver"
        
        # 增加超时到120秒，提供足够时间处理
        timeout 120 "$OPENCLAW_PATH" agent --channel wecom --to "$WE_CHAT_USER" --message "$short_message" --deliver > /tmp/send_output_retry${retry_count}.txt 2>&1
        local exit_code=$?
        
        if [ $exit_code -eq 0 ]; then
            log "✅ 消息发送成功（第${retry_count}次尝试）"
            # 保存成功日志供分析
            if [ -f /tmp/send_output_retry${retry_count}.txt ]; then
                log "成功输出: $(head -c 100 /tmp/send_output_retry${retry_count}.txt)..."
            fi
            rm -f /tmp/send_output_retry*.txt
            return 0
        elif [ $exit_code -eq 124 ]; then
            log "⚠️  发送超时（120秒）- 第${retry_count}次尝试"
            final_exit_code=124
        else
            log "❌ 发送失败，退出码: $exit_code - 第${retry_count}次尝试"
            final_exit_code=$exit_code
            if [ -f /tmp/send_output_retry${retry_count}.txt ]; then
                local error_output=$(head -c 300 /tmp/send_output_retry${retry_count}.txt)
                log "错误输出: $error_output..."
            fi
        fi
    done
    
    log "❌ 所有 ${max_retries} 次发送尝试均失败，最终退出码: $final_exit_code"
    
    # 保存详细的错误信息供分析
    local error_file="/tmp/send_error_$(date +%s).txt"
    echo "发送时间: $(date '+%Y-%m-%d %H:%M:%S')" > "$error_file"
    echo "消息长度: ${#message} 字符" >> "$error_file"
    echo "最终退出码: $final_exit_code" >> "$error_file"
    echo "重试次数: $retry_count" >> "$error_file"
    
    for i in $(seq 1 $retry_count); do
        if [ -f /tmp/send_output_retry${i}.txt ]; then
            echo "=== 第${i}次尝试输出 ===" >> "$error_file"
            cat /tmp/send_output_retry${i}.txt >> "$error_file"
            echo "" >> "$error_file"
        fi
    done
    
    log "详细错误信息已保存到: $error_file"
    
    # 仅当明确失败（非超时）时才发送简短通知
    # 如果是超时，可能消息已发送成功，只是响应慢
    if [ $final_exit_code -ne 124 ] && [ $final_exit_code -ne 0 ]; then
        log "发送简短失败通知..."
        timeout 30 "$OPENCLAW_PATH" agent --channel wecom --to "$WE_CHAT_USER" \
            --message "新闻推送异常（错误码: $final_exit_code），请检查系统。时间: $(date '+%H:%M:%S')" \
            --deliver > /tmp/fail_notice_output.txt 2>&1
        if [ $? -eq 0 ]; then
            log "✅ 简短失败通知已发送"
        else
            log "❌ 简短失败通知发送也失败"
        fi
        rm -f /tmp/fail_notice_output.txt
    else
        log "⚠️ 超时情况，不发送额外通知（消息可能已成功发送）"
    fi
    
    rm -f /tmp/send_output_retry*.txt
    return 1
}

# 主函数
main() {
    log "开始执行简单新闻推送..."
    
    # 获取当前时间
    CURRENT_DATE=$(date '+%Y年%m月%d日')
    PUSH_TIME=$(date '+%H:%M:%S')
    
    # 获取新闻
    local news_titles=$(fetch_news)
    local news_count=$(echo "$news_titles" | wc -l)
    
    # 生成推送消息
    local push_message="🔥 今日热榜（$CURRENT_DATE）\n\n"
    
    if [ "$news_count" -eq 0 ]; then
        push_message+="今日暂时无法获取新闻，请稍后重试。\n"
        log "⚠️ 未获取到新闻"
    else
        push_message+="$news_titles\n"
        log "成功获取 $news_count 条新闻"
    fi
    
    push_message+="\n📊 数据来源：权威新闻媒体\n"
    push_message+="⏰ 推送时间：$PUSH_TIME\n"
    push_message+="💡 提示：如需更多详情，请回复具体新闻编号"
    
    # 发送消息
    if send_message "$push_message"; then
        log "✅ 新闻推送任务完成"
    else
        log "❌ 新闻推送任务失败，消息未发送"
        # 保存消息到文件供手动发送
        local save_file="/tmp/news_push_failed_$(date +%s).txt"
        echo -e "$push_message" > "$save_file"
        log "消息已保存到: $save_file"
        log "可手动执行以下命令发送:"
        echo "$OPENCLAW_PATH agent --channel wecom --to \"$WE_CHAT_USER\" --message \"$(echo -e "$push_message" | head -c 500)\" --deliver"
    fi
    
    log "脚本执行完成"
}

# 执行主函数
main 2>&1 | tee -a "$LOG_FILE"