# MEMORY.md - 长期记忆

## 用户偏好
- 用户 TengTeng 希望每天收到两次新闻推送（早上9点和晚上9点）
- 推送平台：企业微信（WeCom）
- 内容需求：中国热榜TOP10，排除明星八卦和主观评论

## 定时任务
### 当前方案：系统Cron + Shell脚本（优化版）
- **生效中**：每日9:00和21:00执行`simple-news-push.sh`脚本（简化可靠版本）→ **稳定运行**
- **监控任务**：每小时第5分钟执行`monitor-daily-push.sh`监控脚本（用于系统健康检查）
- **状态**：✅ 监控脚本正常运行（已修复脚本名称检查），✅ cron系统事件触发正常，✅ **新闻推送正常运行中**

### 系统运行状态（2026-03-25）
- **推送状态**：
  - ⏹️ **定时任务已取消**：根据老板要求，所有crontab定时任务已删除（包括09:00/21:00新闻推送和每小时监控脚本）
  - ⏹️ 今日（3月25日）没有自动新闻推送计划
- **服务状态**：
  - ✅ **OpenClaw Gateway服务**：运行中（进程PID 2172504，运行稳定）
  - ✅ **虾群IM DM服务器**：运行在 http://81.70.39.176:8800 ，PM2状态online（进程PID 3771396，运行14小时）
  - ⚠️ **虾群IM PWA服务器**：端口3000未监听，服务已停止（需要时可通过PM2重启）
- **heartbeat检查**（10:27）：
  - ✅ 所有核心服务运行正常
  - ✅ OpenClaw Gateway服务运行中（进程PID 2172504，健康检查正常）
  - ✅ 虾群IM DM服务器可访问（HTTP 200 OK），PM2状态online（进程PID 4034455，运行16分钟）
  - ✅ 智虾数据库问题已修复：修改seedUsers函数支持添加缺失用户，智虾用户已在数据库中（token: ddc9bb93-29b4-4228-8968-79b3bca4ae53）
  - ✅ **咕咕嘎嘎指令处理**：已备份虾群IM配置，检查依赖（express/ws/uuid/sql.js/multer）均为最新版本，已回复虾群IM
  - 📢 **关于4001错误码**：澄清给老板，4001是WebSocket连接关闭码（Unauthorized），不是端口号，服务器无需开放4001端口
  - ✅ 系统运行时间：10天23小时
  - ✅ 负载正常：0.02, 0.04, 0.00（之前检查）
  - ✅ 内存使用正常（1.8G/3.6G），磁盘空间充足（32G/99G）
  - ⚠️ 监控脚本已停止运行（最后执行：2026-03-22 22:05）
  - ⚠️ 新闻推送脚本已停止运行（最后执行：2026-03-22 21:04）
  - ⚠️ **虾群IM日志问题**：Webhook连接超虾失败，API使用错误，麻虾频繁连接断开
  - 📝 麻虾配置完成待安全组开放（IP: 34.150.93.21）
  - 📝 昨天有SYN flooding警告（端口8800），但今天无新警告，系统正常处理
  - 🕒 下次检查：下午时段

### 系统运行状态（2026-03-22）
- **推送记录**：
  - ✅ **09:00定时推送成功**（2026-03-22，用户已收到完整热榜，09:00:01开始发送，09:02:54第二次尝试成功）
  - ✅ **21:00定时推送成功**（2026-03-22，用户已收到完整热榜，21:00:01开始发送）
  - ✅ **21:00定时推送成功**（2026-03-21，用户已收到完整热榜，21:00:07开始发送，脚本报告超时（124）但消息实际送达）
- **推送脚本**：`simple-news-push.sh`基本运行，但存在超时误报问题（插件注册耗时超过120秒导致脚本报告失败，但消息实际发送成功）
- **监控脚本**：每小时执行，08:05检查通过（日志显示"所有检查通过"）
- **heartbeat检查**（02:32）：
  - ⏹️ **定时任务已取消**：根据老板要求，已删除所有crontab定时任务，包括09:00/21:00新闻推送和每小时监控脚本
  - ✅ 今日新闻推送已完成（09:00、21:00推送成功发送，用户已收到）
  - ✅ 监控脚本最后运行于22:05（检查通过）
  - ⚠️ **定时任务状态**：所有定时任务已停止，今日不会自动推送新闻（3月24日）
  - ✅ OpenClaw Gateway服务运行中（进程PID 2172504，运行稳定）
  - ⚠️ **虾群IM PWA服务器**：端口3000未监听，服务已停止（健康检查失败，需要时可通过PM2重启）
  - ✅ **虾群IM DM服务器**：运行在 http://81.70.39.176:8800 ，PM2状态online（进程PID 3139418，运行26小时，健康检查200 OK）
  - ✅ **metaso技能安全风险已修复**：API密钥已移至环境变量 `METASO_API_KEY`，硬编码问题已解决（2026-03-24）
  - ⚠️ **推送脚本超时问题**：openclaw agent插件注册耗时超过120秒，导致脚本误报失败，需要调整超时时间或优化启动过程（建议增加到180-240秒）

### 推送脚本修复状态
- **问题**：原脚本发送功能失败（所有4种发送方法均失败）
- **原因**：使用特定OpenClaw路径，而监控脚本使用系统PATH中的`openclaw agent`命令
- **修复**：已简化发送函数，使用与监控脚本相同的`openclaw agent --channel wecom --to "TengTeng"`命令
- **验证**：
  - ✅ 18:11手动测试验证成功
  - ✅ 18:30 cron定时任务验证成功  
  - ✅ **21:00正式定时推送验证成功（关键里程碑）**
  - ✅ **09:00日常推送验证成功**（2026-03-15，系统稳定运行）
  - ✅ **09:00定时推送验证成功**（2026-03-20，用户已收到完整热榜，日志显示超时但实际发送成功）

### 监控系统状态
- ✅ 系统Cron服务正常
- ✅ 监控脚本每小时执行，发送测试消息成功
- ✅ OpenClaw Gateway服务运行中
- ✅ 推送脚本文件存在且可执行
- ✅ 语法检查通过

### 历史问题
- OpenClaw Cron调度异常，任务无法正常执行
- daily-hot-push技能缺乏具体实现代码
- 采用系统Cron + Shell脚本作为稳定解决方案

### 关键文件
- **推送脚本**：`/root/.openclaw/workspace/scripts/simple-news-push.sh`（简化可靠版本，当前使用）
- **旧推送脚本**：`/root/.openclaw/workspace/scripts/daily-hot-push-cron.sh`（历史版本，已归档）
- **监控脚本**：`/root/.openclaw/workspace/scripts/monitor-daily-push.sh`
- **推送日志**：`/tmp/simple-news-push.log`（新脚本日志）
- **监控日志**：`/tmp/daily-push-monitor.log`
- **备份文件**：多个脚本备份和历史cron配置备份已归档

## 技能使用
- daily-hot-push 技能可用，数据源正常（微博、知乎、百度、36氪）
- metaso 技能已安装（秘塔AI搜索集成，支持网页搜索、内容读取、AI问答）✅ **功能测试通过**
- 需要确保飞书/企业微信通道配置正确

## 技术问题
- OpenClaw 版本已统一：运行时 2026.3.11，CLI 2026.3.12
- Gateway 服务正常运行（端口18789）
- ~~推送脚本中的OpenClaw路径需要更新到3.11版本~~（已修复，使用系统PATH中的openclaw命令）
- ~~消息发送机制待验证~~（监控脚本测试消息发送成功，推送脚本已修复）

## 监控与维护
- 每小时检查：监控脚本 `/root/.openclaw/workspace/scripts/monitor-daily-push.sh`
- 运行时间：每小时第5分钟（cron: `5 * * * *`）
- 日志文件：`/tmp/daily-push-monitor.log`
- 检查内容：cron任务、推送脚本、OpenClaw服务、消息发送能力

## 待办事项
1. ~~更新推送脚本中的OpenClaw路径到3.11版本~~（已完成）
2. ~~验证消息发送机制~~（监控脚本测试成功，推送脚本已修复）
3. ~~测试定时推送任务执行效果~~（✅ 手动测试成功，✅ cron定时任务18:30已验证，✅ **21:00正式定时推送验证成功**，✅ **09:00定时推送验证成功**）
4. ~~定期检查任务执行状态~~（✅ 每小时监控脚本已正常运行）
5. ~~清理临时测试任务~~（✅ 已移除17:00、18:10、18:30测试配置，但发现还有9:40测试任务需要清理）
6. ~~系统进入日常运行~~（✅ **2026-03-15 09:00第一次日常推送成功**，系统稳定运行）
7. ~~优化发送命令超时和错误处理~~（✅ 已完成，超时45秒→120秒，添加重试机制，改进错误处理）
8. ~~清理额外测试任务~~（✅ 已完成，cron配置已简化）
9. ~~**metaso API密钥安全**~~（✅ **已完成**：2026-03-24，已将硬编码API密钥移除，改为使用环境变量 `METASO_API_KEY`，技能文件已更新）
10. ~~修复脚本判断逻辑矛盾~~（✅ 已完成，2026-03-19修复，超时不发送重复通知）
11. ~~验证今晚21:00修复效果~~（✅ **已完成**，用户已收到21:00完整推送，优化脚本工作正常）
12. ~~修复监控脚本的脚本名称检查~~（✅ 已完成，2026-03-20 04:12更新）
13. ~~解决浏览器访问问题~~（✅ **已完成**，2026-03-20 09:00，修复ld.so.preload，配置headless Chromium + xvfb，启动CDP服务）
14. ~~修复远程桌面默认浏览器问题~~（✅ **已完成**，2026-03-20 09:25，按超虾方案一执行，创建chromium-remote包装脚本）
15. ~~虾群IM动态用户注册系统开发（任务1+任务2）~~（✅ **已完成**，2026-03-20，任务1：数据库+API后端，任务2：前端角色标识+注册页面+手机适配，代码审查通过）
16. ~~虾群IM任务3（私聊功能）~~（✅ **已完成**：2026-03-21 12:07，4个bug已修复：1.channel排序统一 2.新增sendToUsers函数 3.补loadDMMessages方法 4.修setupMemberDMClicks重复按钮，已向虾群确认；🔄 **重构完成**：2026-03-21 12:15，按超虾要求重构为完整DMManager class，优化防重复按钮逻辑，提供完整代码供审查）
17. **虾群IM任务4（PWA渐进式Web应用）**（✅ **审查完成**：2026-03-21 17:47，DM UI代码审查通过，修复：1.sendDM消息格式正确 2.loadDMHistory调用真实API 3.修复onclick注入风险（改用data属性+事件委托） 4.消息类型统一（群聊\"chat\"/私聊\"send_message\"），代码已更新）
18. ~~虾群IM任务5（DM后端集成）~~（✅ **已完成**：2026-03-21 15:10，sendToUsers函数、case \"send_message\"完整逻辑、/api/messages端点代码审查通过，DM频道格式为`dm:${participants[0]}:${participants[1]}`，后端代码完整可用）
19. ~~虾群IM任务6（DM前端集成 - 第1步）~~（✅ **已完成**：2026-03-21 15:11，已创建dm-manager.js文件，包含完整DMManager class，openDM生成dm:前缀频道，sendDM使用ws.send，超虾审查通过）
20. **虾群IM任务7（DM前端集成 - 第2步）**（✅ **已完成**：2026-03-21 17:45，修改index.html：成员列表加💬按钮、DM频道切换模式、顶部私聊标题+返回按钮、集成DMManager、修改sendMessage支持DM模式，已部署到8800端口）

## 浏览器访问问题（已解决）
**问题**：老板希望远程登录服务器后能正常打开和使用浏览器
**诊断**：
- OpenClaw浏览器服务未运行（gateway超时）
- 云服务器无物理显示器
- xvfb已安装（/usr/bin/xvfb-run）
- chromium-browser可用（/usr/bin/chromium-browser）
- Gateway服务运行正常（PID 1820834）
- 浏览器启动配置需要headless模式和no-sandbox标志

**根本原因**：`/etc/ld.so.preload`配置错误导致libonion.so预加载失败

**解决方案**（2026-03-20 09:00执行）：
1. ✅ 修复`/etc/ld.so.preload`预加载配置
2. ✅ 配置OpenClaw浏览器使用headless+no-sandbox模式
3. ✅ 启动独立的headless Chromium实例（xvfb + 端口9222）
4. ✅ 配置OpenClaw连接到远程CDP服务（attach-only模式）
5. ✅ 重启OpenClaw gateway应用配置

**验证结果**：
- ✅ Chromium headless成功启动（PID 2171784，端口9222）
- ✅ OpenClaw浏览器服务状态：running=true, cdpReady=true
- ✅ 测试页面：百度首页正常打开并截图
- ✅ 浏览器工具：所有功能可用（open/snapshot/act等）

**后续使用**：老板现在可以通过OpenClaw浏览器工具正常访问网页，支持自动化操作。

## 远程桌面浏览器问题（2026-03-20 09:25）
**问题**：老板远程登录后默认浏览器打开失败，显示"failed to execute default web browser input/output error"

**诊断**（基于超虾分析）：
1. xdg-open/默认浏览器配置可能指向不存在或无法启动的路径
2. Chromium启动需要--no-sandbox参数（云服务器root用户限制），但桌面快捷方式没加此参数
3. ld.so.preload问题（libonion.so云安全组件）可能影响GUI模式启动

**解决方案**（方案一，已执行）：
1. ✅ 创建Chromium包装脚本（`/usr/local/bin/chromium-remote`）添加`--no-sandbox --disable-gpu`参数
2. ✅ 创建.desktop文件（`/usr/share/applications/chromium-remote.desktop`）
3. ✅ 当前默认浏览器：`chromium_chromium.desktop`
4. ✅ DISPLAY默认设置：`:0`
5. ⚠️ libonion.so预加载问题已修复，可临时禁用测试

**备选方案**（方案二，如需）：
- 安装Firefox ESR：`apt install firefox-esr`
- 设为默认浏览器：`xdg-settings set default-web-browser firefox.desktop`

**测试方法**：
- 在远程桌面会话中，尝试打开浏览器（默认或chromium-remote）
- 命令行测试：`/usr/local/bin/chromium-remote https://baidu.com`

**状态**：修复已完成，等待测试验证

## 虾群IM开发进展（2026-03-21 12:12）
- **私聊功能4个bug修复完成**：
  1. ✅ channel排序统一（[user1,user2].sort().join(":")）
  2. ✅ sendToUsers函数（遍历wss.clients按userId匹配发送）
  3. ✅ loadDMMessages方法（调用GET /api/messages?channel=...）
  4. ✅ setupMemberDMClicks防重复按钮（先检查.dm-btn是否存在）
- **回复状态**：已向虾群发送修复后的核心代码片段，等待审查
- **下一步**：PWA任务4（Progressive Web App功能）

## 麻虾接入虾群IM（2026-03-21 13:30）
- **任务**：配置新成员"麻虾"（Gemini 3 Flash，香港谷歌云）接入虾群
- **操作**：
  1. ✅ 更新`/root/shrimp-im/server/config.js`：
     - tokens添加：`'maxia': process.env.TOKEN_MAXIA || 'b836c2a1-7c9e-4e5a-8b1d-23f5e92160d5'`
     - members添加：`'maxia': { name: '麻虾', emoji: '🦐', role: 'ai', engine: 'Gemini 3 Flash', location: '香港谷歌云' }`
  2. ✅ 重启虾群IM服务（pm2 restart shrimp-im）
  3. ⚠️ **待完成**：腾讯云安全组开放8800端口给麻虾IP `34.150.93.21`（需要老板在腾讯云控制台操作）
- **状态**：服务器端配置完成，已通知老板配置安全组
- **虾群回复**：已发送确认消息到虾群IM

### 麻虾WebSocket连接问题解决（2026-03-21 13:31）
- **问题**：麻虾报告"能连上，但被秒踢"，怀疑鉴权或消息格式问题
- **分析**：
  1. ✅ 检查虾群IM服务端代码（`/root/shrimp-im/server/index.js`）
  2. ⚠️ **发现关键问题**：麻虾bot使用错误的鉴权方式
- **解决方案**：
  1. **鉴权方式纠正**：token应通过URL参数传递，不是HTTP Header
     - ❌ 错误：`headers: { "Authorization": "Bearer <token>" }`
     - ✅ 正确：`ws://81.70.39.176:8800?token=<token>`
  2. **连接后消息**：无需发送`identify`消息，服务器自动发送`welcome`
  3. **安全组检查**：确认端口8800对`34.150.93.21`开放
- **示例代码**：
  ```javascript
  // 正确连接方式
  ws = new WebSocket(`ws://81.70.39.176:8800?token=${config.token}`);
  ```
- **虾群回复**：已发送技术指导给老板，等待麻虾测试结果

## 虾群IM历史记录权限问题（2026-03-22 15:01）
- **老板需求**：登录后能看到所有聊天记录，包括最初最开始的
- **现状分析**：
  - 数据库中有703条general频道消息（时间范围：2026-03-16 12:04:10 至 2026-03-22 07:01:36）
  - 当前配置限制：只加载最近200条（config.historyLimit = 200）
  - boss角色在配置中为管理员（role: 'boss'）
- **解决方案提议**：
  1. 提高boss角色的历史记录限制（如从200改为10000或无限）
  2. 添加管理员专属API端点，boss可访问完整历史
- **已回复虾群**：告知老板可行，等待方案选择
- **技术准备**：可修改`/root/shrimp-im/server/index.js`中欢迎消息部分，根据userInfo.role动态调整limit

## 虾群IM开源代码打包（2026-03-22 16:23）
- **老板需求**：虾群IM全代码打包下载链接，要能放进GitHub做开源项目
- **操作**：
  1. ✅ 从超虾备份中提取完整项目结构
  2. ✅ 清理敏感文件（日志、数据库、临时文件）
  3. ✅ 打包为开源版本（76KB，排除node_modules）
  4. ✅ 文件位置：`/root/shrimp-im/server/public/shrimp-im-open-source.tar.gz`
- **下载链接**：http://81.70.39.176:8800/shrimp-im-open-source.tar.gz
- **包含内容**：
  - 前后端完整代码（server/ + client/）
  - 配置文件（使用环境变量占位符）
  - 文档（README.md、部署脚本）
  - 已排除：敏感数据、日志、数据库、临时文件
- **虾群回复**：已发送下载链接给老板（16:23）

## 智虾接入虾群IM（2026-03-24 16:49）
- **老板需求**：新成员"智虾"（GLM-5-Turbo，老板办公室）接入虾群IM
- **操作**：
  1. ✅ 生成智虾Token：`ddc9bb93-29b4-4228-8968-79b3bca4ae53`
  2. ✅ 更新`/root/shrimp-im/server/config.js`：
     - tokens添加：`'zhixia': process.env.TOKEN_ZHIXIA || 'ddc9bb93-29b4-4228-8968-79b3bca4ae53'`
     - members添加：`'zhixia': { name: '智虾', emoji: '🦐', role: 'ai', engine: 'GLM-5-Turbo', location: '老板办公室' }`
  3. ✅ 重启虾群IM服务（pm2 restart shrimp-im）
  4. ✅ 虾群回复：发送Token和接入指南给老板
- **问题发现**（2026-03-25 10:02）：
  - 智虾连接失败，错误："智虾用户: 不存在 当前用户总数: 8"
  - **根本原因**：智虾token在config.js中，但未同步到数据库users表
  - **数据库机制**：虾群IM只在users表为空时从config同步数据（seedUsers函数），已有用户时不会自动添加新用户
- **修复操作**：
  1. ✅ 修改`config.seedUsers: true`，修改`db.js`的seedUsers函数支持添加缺失用户
  2. ✅ 重启虾群IM服务，智虾用户自动添加到数据库
  3. ✅ 恢复原配置，验证智虾在用户表中
  4. ✅ 智虾数据库记录：
     - id: 3a2ca39e-e4c2-4426-9aa7-a29437ffff5d
     - username: zhixia
     - token: ddc9bb93-29b4-4228-8968-79b3bca4ae53
     - role: ai, engine: GLM-5-Turbo, location: 老板办公室
- **状态**：✅ **智虾数据库问题已修复**，✅ **智虾已成功连接虾群IM**（2026-03-25 10:38）