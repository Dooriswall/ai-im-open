const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const config = require('./config');
const db = require('./db');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 初始化数据库
db.init().then(() => {
  console.log('📦 Database initialized');
  
  // 导入种子用户（如果配置了且用户表为空）
  if (config.seedUsers !== false) {
    const seedResult = db.seedUsers();
    if (seedResult.seeded) {
      console.log(`🌱 Seeded ${seedResult.count} users from config`);
    } else {
      console.log(`📝 ${seedResult.message}`);
    }
  }
  
  // 强制删除测试账号 lorenzo（如果存在）
  const lorenzoUser = db.getUserByUsername('lorenzo');
  if (lorenzoUser) {
    console.log(`🗑️  Deleting test account lorenzo (${lorenzoUser.display_name})`);
    const result = db.deleteUser('lorenzo');
    console.log(`✅ ${result.deleted ? 'Deleted' : 'Failed to delete'} lorenzo`);
  }
}).catch(err => {
  console.error('❌ Database init failed:', err);
  process.exit(1);
});

// ========== 认证 ==========

function authenticateToken(token) {
  const user = db.getUserByToken(token);
  return user ? user.username : null;
}

// 从数据库获取用户信息（格式与config.members兼容）
function getUserInfoFromDb(username) {
  const user = db.getUserByUsername(username);
  if (!user) return null;
  
  return {
    name: user.display_name,
    emoji: user.emoji,
    role: user.role,
    engine: user.engine,
    location: user.location,
    avatar_url: user.avatar_url
  };
}

function authMiddleware(req, res, next) {
  const token = req.headers['authorization']?.replace('Bearer ', '') || req.query.token;
  const userId = authenticateToken(token);
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });
  req.userId = userId;
  req.userInfo = getUserInfoFromDb(userId);
  next();
}

// ========== 在线状态 ==========

const onlineClients = new Map(); // userId -> Set<ws>

// 从数据库获取所有用户信息（格式与config.members兼容）
function getAllMembersFromDb() {
  const users = db.getAllUsers();
  const members = {};
  users.forEach(user => {
    members[user.username] = {
      name: user.display_name,
      emoji: user.emoji,
      role: user.role,
      engine: user.engine,
      location: user.location,
      avatar_url: user.avatar_url
    };
  });
  return members;
}

function broadcastOnlineList() {
  const online = {};
  for (const [userId, sockets] of onlineClients) {
    if (sockets.size > 0) {
      const userInfo = getUserInfoFromDb(userId);
      if (userInfo) {
        online[userId] = { ...userInfo, connections: sockets.size };
      }
    }
  }
  broadcast({ type: 'online', data: online });
}

function broadcast(msg, excludeWs = null) {
  const data = JSON.stringify(msg);
  wss.clients.forEach(client => {
    if (client !== excludeWs && client.readyState === 1) {
      client.send(data);
    }
  });
}

// 发送消息给指定用户列表
function sendToUsers(userIds, msg, excludeWs = null) {
  const data = JSON.stringify(msg);
  wss.clients.forEach(client => {
    if (client !== excludeWs && client.readyState === 1 && userIds.includes(client.userId)) {
      client.send(data);
    }
  });
}

// ========== WebSocket ==========

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const token = url.searchParams.get('token');
  const userId = authenticateToken(token);

  if (!userId) {
    ws.close(4001, 'Unauthorized');
    return;
  }

  const userInfo = getUserInfoFromDb(userId);
  if (!userInfo) {
    ws.close(4002, 'User not found in database');
    return;
  }
  
  ws.userId = userId;
  ws.userInfo = userInfo;
  ws.isAlive = true;

  // 注册在线
  if (!onlineClients.has(userId)) onlineClients.set(userId, new Set());
  onlineClients.get(userId).add(ws);

  console.log(`[+] ${userInfo.name} (${userId}) connected`);

  // 发送欢迎消息和历史
  ws.send(JSON.stringify({
    type: 'welcome',
    data: {
      userId,
      userInfo,
      members: getAllMembersFromDb(),
      history: db.getHistory('general', userId === 'boss' ? 99999 : config.historyLimit),
    }
  }));

  broadcastOnlineList();

  // 处理消息
  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw);
      handleWsMessage(ws, userId, msg);
    } catch (e) {
      ws.send(JSON.stringify({ type: 'error', data: 'Invalid JSON' }));
    }
  });

  // 心跳
  ws.on('pong', () => { ws.isAlive = true; });

  // 断开
  ws.on('close', () => {
    console.log(`[-] ${ws.userInfo?.name || userId} (${userId}) disconnected`);
    onlineClients.get(userId)?.delete(ws);
    if (onlineClients.get(userId)?.size === 0) onlineClients.delete(userId);
    broadcastOnlineList();
  });
});

function handleWsMessage(ws, userId, msg) {
  switch (msg.type) {
    case 'chat': {
      const uid = uuidv4();
      const channel = msg.channel || 'general';
      const content = (msg.content || '').trim();
      if (!content) return;
      if (content.length > 10000) {
        ws.send(JSON.stringify({ type: 'error', data: 'Message too long (max 10000 chars)' }));
        return;
      }

      const saved = db.saveMessage({
        uid,
        sender: userId,
        channel,
        content,
        type: 'text',
      });

      const outMsg = {
        type: 'chat',
        data: {
          id: saved.lastInsertRowid,
          uid,
          sender: userId,
          senderInfo: getUserInfoFromDb(userId),
          channel,
          content,
          type: 'text',
          created_at: new Date().toISOString(),
        }
      };

      // 私聊消息处理
      if (channel.startsWith('dm:')) {
        // 解析私聊参与者
        const parts = channel.split(':');
        if (parts.length >= 3) {
          const user1 = parts[1];
          const user2 = parts[2];
          
          // 更新私聊会话时间
          const conversation = db.createDM(user1, user2);
          if (conversation && conversation.id) {
            db.updateDMTime(conversation.id);
          }
          
          // 只发送给私聊双方
          sendToUsers([user1, user2], outMsg, ws);
        } else {
          // 格式错误，降级为广播
          broadcast(outMsg);
        }
      } else {
        // 普通频道消息，广播给所有人
        broadcast(outMsg);
      }
      
      dispatchWebhooks(outMsg, channel);
      break;
    }

    case 'typing': {
      broadcast({
        type: 'typing',
        data: { userId, userInfo: getUserInfoFromDb(userId) }
      }, ws);
      break;
    }

    case 'ping': {
      ws.send(JSON.stringify({ type: 'pong', data: Date.now() }));
      break;
    }

    case 'send_message': {
      // 处理私聊消息，格式: { type: 'send_message', to: 'targetUserId', content: 'message' }
      const targetUserId = msg.to;
      const content = (msg.content || '').trim();
      
      if (!targetUserId || !content) {
        ws.send(JSON.stringify({ type: 'error', data: 'to and content are required for send_message' }));
        return;
      }
      
      if (content.length > 10000) {
        ws.send(JSON.stringify({ type: 'error', data: 'Message too long (max 10000 chars)' }));
        return;
      }
      
      // 检查目标用户是否存在
      const targetUser = db.getUserByUsername(targetUserId);
      if (!targetUser) {
        ws.send(JSON.stringify({ type: 'error', data: 'Target user not found' }));
        return;
      }
      
      // 不能给自己发消息
      if (targetUserId === userId) {
        ws.send(JSON.stringify({ type: 'error', data: 'Cannot send message to yourself' }));
        return;
      }
      
      const uid = uuidv4();
      // 构建DM频道名称，确保顺序一致（按字母顺序排序）
      const participants = [userId, targetUserId].sort();
      const channel = `dm:${participants[0]}:${participants[1]}`;
      
      const saved = db.saveMessage({
        uid,
        sender: userId,
        channel,
        content,
        type: 'text',
      });
      
      // 更新私聊会话时间
      const conversation = db.createDM(userId, targetUserId);
      if (conversation && conversation.id) {
        db.updateDMTime(conversation.id);
      }
      
      const outMsg = {
        type: 'chat',
        data: {
          id: saved.lastInsertRowid,
          uid,
          sender: userId,
          senderInfo: getUserInfoFromDb(userId),
          channel,
          content,
          type: 'text',
          created_at: new Date().toISOString(),
        }
      };
      
      // 发送给私聊双方
      sendToUsers([userId, targetUserId], outMsg, ws);
      dispatchWebhooks(outMsg, channel);
      break;
    }
  }
}

// ========== Webhook推送 ==========

async function dispatchWebhooks(chatMsg, channel) {
  const sender = chatMsg.data.sender;
  
  // 确定需要发送webhook的用户列表
  let targetUsers = Object.keys(config.webhooks);
  
  // 如果是私聊消息，只发送给私聊对方
  if (channel && channel.startsWith('dm:')) {
    const parts = channel.split(':');
    if (parts.length >= 3) {
      const user1 = parts[1];
      const user2 = parts[2];
      // 发送给私聊对方（排除自己）
      targetUsers = targetUsers.filter(userId => 
        (userId === user1 || userId === user2) && userId !== sender
      );
    }
  }
  
  for (const userId of targetUsers) {
    const hook = config.webhooks[userId];
    if (!hook || !hook.url) continue;
    if (hook.excludeSelf && userId === sender) continue;
    
    try {
      const payload = JSON.stringify({
        type: 'new_message',
        message: chatMsg.data,
        timestamp: Date.now(),
      });

      const headers = {
        'Content-Type': 'application/json',
      };
      if (hook.secret) {
        headers['X-Webhook-Secret'] = hook.secret;
      }

      // 使用Node原生http/https发请求
      const url = new URL(hook.url);
      const lib = url.protocol === 'https:' ? require('https') : require('http');
      
      const req = lib.request(url, {
        method: 'POST',
        headers,
        timeout: 10000,
      }, (res) => {
        let body = '';
        res.on('data', c => body += c);
        res.on('end', () => {
          console.log(`[webhook] -> ${userId} (${res.statusCode})`);
        });
      });
      
      req.on('error', (err) => {
        console.error(`[webhook] -> ${userId} FAILED: ${err.message}`);
      });
      
      req.write(payload);
      req.end();
    } catch (err) {
      console.error(`[webhook] -> ${userId} ERROR: ${err.message}`);
    }
  }
}

// 心跳检测
setInterval(() => {
  wss.clients.forEach(ws => {
    if (!ws.isAlive) return ws.terminate();
    ws.isAlive = false;
    ws.ping();
  });
}, config.heartbeatInterval);

// ========== HTTP API（供AI客户端使用） ==========

// 发消息
app.post('/api/messages', authMiddleware, (req, res) => {
  const { content, channel = 'general' } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Content required' });
  if (content.length > 10000) return res.status(400).json({ error: 'Message too long' });

  const uid = uuidv4();
  const saved = db.saveMessage({
    uid,
    sender: req.userId,
    channel,
    content: content.trim(),
    type: 'text',
  });

  const outMsg = {
    type: 'chat',
    data: {
      id: saved.lastInsertRowid,
      uid,
      sender: req.userId,
      senderInfo: req.userInfo,
      channel,
      content: content.trim(),
      type: 'text',
      created_at: new Date().toISOString(),
    }
  };

  broadcast(outMsg);
  dispatchWebhooks(outMsg);
  res.json({ ok: true, message: outMsg.data });
});

// 获取历史消息
app.get('/api/messages', authMiddleware, (req, res) => {
  const channel = req.query.channel || 'general';
  const maxLimit = req.userId === 'boss' ? 99999 : 500;
  const limit = Math.min(parseInt(req.query.limit) || 100, maxLimit);
  
  // 老板特权：可以查看所有频道的历史记录
  if (req.userId === 'boss' && channel === 'all') {
    res.json({ ok: true, messages: db.getAllHistory(limit), isAll: true });
    return;
  }
  
  res.json({ ok: true, messages: db.getHistory(channel, limit) });
});

// 获取新消息（轮询用）
app.get('/api/messages/since/:lastId', authMiddleware, (req, res) => {
  const channel = req.query.channel || 'general';
  const lastId = parseInt(req.params.lastId) || 0;
  res.json({ ok: true, messages: db.getMessagesSince(channel, lastId) });
});

// 成员列表（从数据库获取）
app.get('/api/members', authMiddleware, (req, res) => {
  const online = {};
  for (const [userId, sockets] of onlineClients) {
    if (sockets.size > 0) online[userId] = true;
  }
  const users = db.getAllUsers();
  const members = users.map(user => ({
    id: user.username,
    name: user.display_name,
    emoji: user.emoji,
    role: user.role,
    engine: user.engine,
    location: user.location,
    avatar_url: user.avatar_url,
    online: !!online[user.username],
    created_at: user.created_at,
    last_seen: user.last_seen,
  }));
  res.json({ ok: true, members });
});

// 注册/更新Webhook
app.post('/api/webhook', authMiddleware, (req, res) => {
  const { url, secret } = req.body;
  if (!url) return res.status(400).json({ error: 'url required' });
  
  config.webhooks[req.userId] = {
    url,
    secret: secret || '',
    excludeSelf: true,
  };
  
  console.log(`[webhook] Registered for ${req.userId}: ${url}`);
  res.json({ ok: true, userId: req.userId, url });
});

// 查看Webhook状态
app.get('/api/webhook', authMiddleware, (req, res) => {
  const hook = config.webhooks[req.userId];
  res.json({ ok: true, webhook: hook || null });
});

// 删除Webhook
app.delete('/api/webhook', authMiddleware, (req, res) => {
  if (config.webhooks[req.userId]) {
    config.webhooks[req.userId].url = '';
  }
  res.json({ ok: true });
});

// 频道管理 API
// 创建频道
app.post('/api/channels', authMiddleware, (req, res) => {
  const { name, description = '', is_private = false } = req.body;
  
  if (!name || !name.trim()) {
    return res.status(400).json({ error: 'Channel name is required' });
  }
  
  // 频道名称格式校验（字母数字下划线短横线，3-30字符）
  if (!/^[a-zA-Z0-9_-]{3,30}$/.test(name)) {
    return res.status(400).json({ error: 'Channel name must be 3-30 chars, alphanumeric, underscore, or hyphen' });
  }
  
  // 检查频道是否已存在
  const existingChannel = db.getChannelByName(name);
  if (existingChannel) {
    return res.status(409).json({ error: 'Channel already exists' });
  }
  
  try {
    const channel = db.createChannel({
      name,
      description: description.trim(),
      created_by: req.userId,
      is_private: is_private ? 1 : 0,
    });
    
    res.json({
      ok: true,
      channel
    });
  } catch (error) {
    console.error('Channel creation error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// 获取频道列表
app.get('/api/channels', authMiddleware, (req, res) => {
  const channels = db.getChannels();
  const user = db.getUserByUsername(req.userId);
  
  // 过滤频道：公开频道 + 用户创建的私有频道 + 老板可看到所有频道
  const filtered = channels.filter(channel => {
    if (channel.is_private === 0) return true; // 公开频道
    if (channel.created_by === req.userId) return true; // 用户创建的私有频道
    if (user && user.role === 'boss') return true; // 老板可看到所有频道
    return false;
  });
  
  res.json({ ok: true, channels: filtered });
});

// 删除频道
app.delete('/api/channels/:name', authMiddleware, (req, res) => {
  const { name } = req.params;
  
  const channel = db.getChannelByName(name);
  if (!channel) {
    return res.status(404).json({ error: 'Channel not found' });
  }
  
  // 权限检查：只有创建者可以删除（system创建的频道如general只能由boss删除）
  if (channel.created_by !== req.userId && channel.created_by !== 'system') {
    return res.status(403).json({ error: 'Only channel creator can delete' });
  }
  
  // 不能删除默认general频道
  if (name === 'general') {
    return res.status(403).json({ error: 'Cannot delete the general channel' });
  }
  
  const result = db.deleteChannel(name, req.userId);
  if (!result.deleted) {
    return res.status(result.error === 'Permission denied' ? 403 : 404).json({ error: result.error || 'Failed to delete channel' });
  }
  res.json({ ok: true, result });
});

// 私聊管理 API
// 获取我的私聊列表
app.get('/api/dm', authMiddleware, (req, res) => {
  try {
    const dmList = db.getDMList(req.userId);
    res.json({ ok: true, conversations: dmList });
  } catch (error) {
    console.error('Get DM list error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// 创建或打开私聊
app.post('/api/dm', authMiddleware, (req, res) => {
  const { targetUserId } = req.body;
  
  if (!targetUserId || targetUserId.trim() === '') {
    return res.status(400).json({ error: 'targetUserId is required' });
  }
  
  // 检查目标用户是否存在
  const targetUser = db.getUserByUsername(targetUserId);
  if (!targetUser) {
    return res.status(404).json({ error: 'Target user not found' });
  }
  
  // 不能和自己私聊（可选，可以允许）
  if (targetUserId === req.userId) {
    return res.status(400).json({ error: 'Cannot start DM with yourself' });
  }
  
  try {
    // 创建或获取现有私聊会话
    const conversation = db.createDM(req.userId, targetUserId);
    
    res.json({
      ok: true,
      conversation: {
        ...conversation,
        partner: {
          id: targetUser.id,
          username: targetUser.username,
          displayName: targetUser.display_name,
          emoji: targetUser.emoji,
          role: targetUser.role,
          engine: targetUser.engine,
          location: targetUser.location,
        }
      }
    });
  } catch (error) {
    console.error('Create DM error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// 用户注册（无需认证）
app.post('/api/register', (req, res) => {
  const { username, displayName, emoji = '👤' } = req.body;
  
  // 参数校验
  if (!username || !displayName) {
    return res.status(400).json({ error: 'username and displayName are required' });
  }
  
  // 用户名格式校验（字母数字下划线）
  if (!/^[a-zA-Z0-9_-]{3,30}$/.test(username)) {
    return res.status(400).json({ error: 'username must be 3-30 chars, alphanumeric, underscore, or hyphen' });
  }
  
  // 检查用户名是否已存在
  const existingUser = db.getUserByUsername(username);
  if (existingUser) {
    return res.status(409).json({ error: 'username already exists' });
  }
  
  try {
    // 创建用户
    const user = db.createUser({
      username,
      displayName,
      emoji,
      role: 'human', // 默认人类用户，AI用户可以通过其他方式创建
    });
    
    res.json({
      ok: true,
      user: {
        id: user.id,
        username: user.username,
        displayName: user.displayName,
        token: user.token,
        emoji: user.emoji,
        role: user.role,
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// 消息搜索 API
app.get('/api/messages/search', authMiddleware, (req, res) => {
  const query = (req.query.q || '').trim();
  if (!query) return res.status(400).json({ error: 'Search query (q) is required' });
  const channel = req.query.channel || null; // null = search all channels
  const limit = Math.min(parseInt(req.query.limit) || 50, 200);
  
  try {
    const messages = db.searchMessages(query, channel, limit);
    res.json({ ok: true, query, messages });
  } catch (err) {
    console.error('Search error:', err);
    res.status(500).json({ error: 'Search failed' });
  }
});

// 频道成员管理 API
// 获取频道成员
app.get('/api/channels/:name/members', authMiddleware, (req, res) => {
  const { name } = req.params;
  const channel = db.getChannelByName(name);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });
  
  const members = db.getChannelMembers(name);
  res.json({ ok: true, channel: name, members });
});

// 添加频道成员
app.post('/api/channels/:name/members', authMiddleware, (req, res) => {
  const { name } = req.params;
  const { username } = req.body;
  
  if (!username) return res.status(400).json({ error: 'username is required' });
  
  const channel = db.getChannelByName(name);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });
  
  // Only channel creator or boss can add members
  const user = db.getUserByUsername(req.userId);
  if (channel.created_by !== req.userId && (!user || user.role !== 'boss')) {
    return res.status(403).json({ error: 'Permission denied' });
  }
  
  // Check target user exists
  const targetUser = db.getUserByUsername(username);
  if (!targetUser) return res.status(404).json({ error: 'User not found' });
  
  const result = db.addChannelMember(name, username, req.userId);
  res.json({ ok: true, ...result });
});

// 移除频道成员
app.delete('/api/channels/:name/members/:username', authMiddleware, (req, res) => {
  const { name, username } = req.params;
  
  const channel = db.getChannelByName(name);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });
  
  // Only channel creator or boss can remove members
  const user = db.getUserByUsername(req.userId);
  if (channel.created_by !== req.userId && (!user || user.role !== 'boss')) {
    return res.status(403).json({ error: 'Permission denied' });
  }
  
  const result = db.removeChannelMember(name, username);
  res.json({ ok: true, ...result });
});

// 健康检查
app.get('/api/health', (req, res) => {
  res.json({ ok: true, name: '虾群IM', version: '0.1.0', uptime: process.uptime() });
});

// ========== 启动 ==========

server.listen(config.port, '0.0.0.0', () => {
  console.log(`
🦐 虾群IM 服务器启动!
📡 端口: ${config.port}
🌐 Web UI: http://0.0.0.0:${config.port}
📊 API: http://0.0.0.0:${config.port}/api/health
  `);
});
