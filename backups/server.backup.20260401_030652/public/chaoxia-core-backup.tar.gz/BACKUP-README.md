# 超虾 (Super Shrimp) 备份还原指南 🦐

## 备份内容

`chaoxia-core-backup.tar.gz` 包含超虾的所有核心文件：

### 身份文件
- `SOUL.md` — 超虾的灵魂（性格、行为准则）
- `IDENTITY.md` — 身份信息（名字、同事列表）
- `USER.md` — 老板信息
- `AGENTS.md` — 工作行为规范
- `TOOLS.md` — 工具笔记
- `HEARTBEAT.md` — 心跳任务配置

### 记忆
- `memory/` — 每日记忆日志（YYYY-MM-DD.md）
- `MEMORY.md` — 长期记忆（如果存在）

### 虾群IM
- `shrimp-im/` — 虾群IM完整代码（不含node_modules）
  - `server/` — 服务端代码 + 数据库
  - `client/` — 客户端SDK
  - `upgrade/` — 升级脚本和补丁

## 如何在新服务器上复活超虾

### 1. 安装 OpenClaw
```bash
# 在新服务器上
npm install -g openclaw
openclaw init
```

### 2. 恢复 workspace
```bash
# 解压备份到 OpenClaw workspace
cd ~/.openclaw/workspace
tar -xzf /path/to/chaoxia-core-backup.tar.gz
```

### 3. 配置 AI 模型
OpenClaw 配置文件在 `~/.openclaw/config.yaml`：
```yaml
model: anthropic/claude-opus-4-6
```

### 4. SSH 密钥
超虾的 SSH 密钥用于连接火山星人服务器：
- 私钥：`~/.ssh/id_chaoxia`
- 对应服务器：`81.70.39.176`（火山星人/腾讯云）

需要手动复制 SSH 密钥（不包含在备份中，安全原因）。

### 5. 虾群IM 服务端
虾群IM 运行在火山星人服务器上（81.70.39.176:8800），不需要在 OpenClaw 服务器上启动。
如果要迁移虾群IM服务端，参考 `shrimp-im/README.md`。

## 服务器信息
- **超虾 OpenClaw**: 德国法兰克福 EC2 (3.121.237.17)
- **火山星人/虾群IM**: 腾讯云 (81.70.39.176:8800)
- **模型**: Anthropic Claude Opus 4

## 注意事项
- node_modules 不包含在备份中，恢复后需要 `npm install`
- SSH 密钥不包含在备份中，需要单独保存
- 虾群IM 的 token 存在火山星人服务器的 `.env` 文件中
