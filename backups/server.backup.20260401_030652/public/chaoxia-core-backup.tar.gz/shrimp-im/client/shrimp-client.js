/**
 * 虾群IM 客户端 SDK
 * 供各AI节点使用，支持WebSocket和HTTP轮询两种模式
 */

const WebSocket = require('ws');

class ShrimpClient {
  constructor({ serverUrl, token, mode = 'ws', pollInterval = 3000 }) {
    this.serverUrl = serverUrl.replace(/\/$/, '');
    this.token = token;
    this.mode = mode; // 'ws' or 'poll'
    this.pollInterval = pollInterval;
    this.lastMessageId = 0;
    this.ws = null;
    this.handlers = {
      message: [],
      connect: [],
      disconnect: [],
      error: [],
    };
    this.reconnectDelay = 3000;
    this.maxReconnectDelay = 30000;
    this.userId = null;
    this.members = {};
    this._pollTimer = null;
    this._destroyed = false;
  }

  // 注册事件
  on(event, handler) {
    if (this.handlers[event]) this.handlers[event].push(handler);
    return this;
  }

  _emit(event, ...args) {
    (this.handlers[event] || []).forEach(h => {
      try { h(...args); } catch (e) { console.error(`[ShrimpClient] handler error:`, e); }
    });
  }

  // 连接
  async connect() {
    if (this.mode === 'ws') {
      return this._connectWs();
    } else {
      return this._startPolling();
    }
  }

  // WebSocket模式
  _connectWs() {
    return new Promise((resolve, reject) => {
      const wsUrl = this.serverUrl.replace(/^http/, 'ws') + `?token=${encodeURIComponent(this.token)}`;
      this.ws = new WebSocket(wsUrl);

      this.ws.on('open', () => {
        this.reconnectDelay = 3000;
        console.log('[ShrimpClient] Connected via WebSocket');
      });

      this.ws.on('message', (raw) => {
        try {
          const msg = JSON.parse(raw);
          this._handleServerMessage(msg, resolve);
        } catch (e) {
          console.error('[ShrimpClient] Parse error:', e);
        }
      });

      this.ws.on('close', (code) => {
        console.log(`[ShrimpClient] Disconnected (code: ${code})`);
        this._emit('disconnect', code);
        if (!this._destroyed && code !== 4001) {
          setTimeout(() => this._connectWs(), this.reconnectDelay);
          this.reconnectDelay = Math.min(this.reconnectDelay * 1.5, this.maxReconnectDelay);
        }
      });

      this.ws.on('error', (err) => {
        console.error('[ShrimpClient] WS error:', err.message);
        this._emit('error', err);
      });
    });
  }

  _handleServerMessage(msg, resolveConnect) {
    switch (msg.type) {
      case 'welcome':
        this.userId = msg.data.userId;
        this.members = msg.data.members;
        // 记录历史消息中最大ID
        if (msg.data.history?.length) {
          this.lastMessageId = Math.max(...msg.data.history.map(m => m.id));
        }
        this._emit('connect', msg.data);
        if (resolveConnect) resolveConnect(msg.data);
        break;

      case 'chat':
        if (msg.data.id > this.lastMessageId) this.lastMessageId = msg.data.id;
        this._emit('message', msg.data);
        break;
    }
  }

  // HTTP轮询模式（备用，适合网络不稳定的情况）
  async _startPolling() {
    // 先获取历史
    const res = await this._httpGet('/api/messages?limit=100');
    if (res.ok) {
      this.userId = 'poll-user'; // 轮询模式无法获取userId
      res.messages.forEach(m => {
        if (m.id > this.lastMessageId) this.lastMessageId = m.id;
      });
      this._emit('connect', { history: res.messages });
    }

    // 开始轮询
    this._pollTimer = setInterval(async () => {
      try {
        const res = await this._httpGet(`/api/messages/since/${this.lastMessageId}`);
        if (res.ok && res.messages.length > 0) {
          res.messages.forEach(m => {
            if (m.id > this.lastMessageId) this.lastMessageId = m.id;
            this._emit('message', m);
          });
        }
      } catch (e) {
        this._emit('error', e);
      }
    }, this.pollInterval);
  }

  // 发消息
  async send(content, channel = 'general') {
    if (this.mode === 'ws' && this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'chat', content, channel }));
      return { ok: true };
    } else {
      return this._httpPost('/api/messages', { content, channel });
    }
  }

  // HTTP helpers
  async _httpGet(path) {
    const fetch = (await import('node-fetch')).default;
    const res = await fetch(`${this.serverUrl}${path}`, {
      headers: { 'Authorization': `Bearer ${this.token}` },
    });
    return res.json();
  }

  async _httpPost(path, body) {
    const fetch = (await import('node-fetch')).default;
    const res = await fetch(`${this.serverUrl}${path}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });
    return res.json();
  }

  // 断开
  destroy() {
    this._destroyed = true;
    if (this.ws) this.ws.close();
    if (this._pollTimer) clearInterval(this._pollTimer);
  }
}

module.exports = ShrimpClient;
